package krusader.terminal;


import gnu.io.CommPortIdentifier;

import java.util.Enumeration;
import java.util.HashMap;

//import javax.comm.CommPortIdentifier;

public class TerminalSettings
{
  private String portName;
  public static HashMap<String, CommPortIdentifier> ports = new HashMap<String, CommPortIdentifier>();
  
  // default settings for Replica 1 serial communications
  private int baud = 2400;
  private int databits = 8;
  private StopBits stopbits = StopBits.ONE;
  private Parity parity = Parity.NONE;
  private FlowControl flow = FlowControl.NONE;
  private int linesToShow = 1000;
  
  private EOL eol;
  private int charDelay = 10;
  private int lineDelay = 200;

  static
  {
    Enumeration pList = CommPortIdentifier.getPortIdentifiers();

    while (pList.hasMoreElements()) 
    {
      CommPortIdentifier cpi = (CommPortIdentifier)pList.nextElement();
      if (cpi.getPortType() == CommPortIdentifier.PORT_SERIAL) 
      {
        ports.put(cpi.getName(), cpi);
      }
    }
  }

  public TerminalSettings()
  {
    super();
  }
  
  public TerminalSettings(String portName, int baud, StopBits stopbits, int databits, 
      Parity parity, FlowControl flow, EOL eol, int charDelay, int lineDelay)
  {
    this.portName = portName;
    this.baud = baud;
    this.stopbits = stopbits;
    this.databits = databits;
    this.parity = parity;
    this.flow = flow;
    this.eol = eol;
    this.charDelay = charDelay;
    this.lineDelay = lineDelay;
  }
  
  public static TerminalSettings createReplica1Default()
  {
    EOL defaultEOL = EOL.fromString(System.getProperty("line.separator"));
    return new TerminalSettings("COM1", 2400, StopBits.ONE, 8, Parity.NONE, 
        FlowControl.NONE, defaultEOL, 10, 200);
  }

  public static TerminalSettings createACIADefault()
  {
    EOL defaultEOL = EOL.fromString(System.getProperty("line.separator"));
    return new TerminalSettings("COM1", 19200, StopBits.ONE, 8, Parity.NONE, 
        FlowControl.NONE, defaultEOL, 1, 2);
  }

  public String getPortName() { return portName; }
  public void setPortName(String name) { this.portName = name; }
  public CommPortIdentifier getPort() { return ports.get(portName); }
  
  public int getBaud() { return baud; }
  public void setBaud(int baud) { this.baud = baud; }

  public int getDatabits() { return databits; }
  public void setDatabits(int databits) { this.databits = databits; }

  public FlowControl getFlow() { return flow; }
  public void setFlow(FlowControl flow) { this.flow = flow; }

  public EOL getLineTerminator() { return eol; }
  public void setLineTerminator(EOL eol) { this.eol = eol; }

  public Parity getParity() { return parity; }
  public void setParity(Parity parity) { this.parity = parity; }

  public StopBits getStopbits() { return stopbits; }
  public void setStopbits(StopBits stopbits) { this.stopbits = stopbits; }

  public int getCharDelay() { return charDelay; }
  public void setCharDelay(int delay) { this.charDelay = delay; }

  public int getLineDelay() { return lineDelay; }
  public void setLineDelay(int delay) { this.lineDelay = delay; }

  public int getLinesToShow() { return linesToShow; }
  public void setLinesToShow(int linesToShow) { this.linesToShow = linesToShow; }

  public TerminalSettings clone() throws CloneNotSupportedException 
  {
    return new TerminalSettings(portName, baud, stopbits, databits, parity, flow, eol, charDelay, lineDelay);
  }

  public static String [] getPorts() 
  {
    return ports.keySet().toArray(new String [] {});
  }
}
