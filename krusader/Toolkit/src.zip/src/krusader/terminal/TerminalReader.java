package krusader.terminal;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

import krusader.emulator.EmulatorPane;

public class TerminalReader extends Thread
{
  InputStream isIn = null;
  TerminalPane terminal;
  TerminalSettings settings;

  /**
   * Creates a new instance of SerialTestToolReader
   */
  public TerminalReader(InputStream in, TerminalPane terminal, TerminalSettings settings)
  {
    isIn = in;
    this.terminal = terminal;
    this.settings = settings;
    setPriority(Thread.MIN_PRIORITY);
  }

  // Thread used to read data from SerialPort InputStream and write to screen or
  // file
  public void run()
  {
    // data transfer array
    byte[] baData = new byte[100];
    // number of bytes read, used during file receive
    int iBytesRead = 0;

    while (terminal.isConnected())
    {
      try
      {
        // check InputStream is not null
        if (isIn != null)
        {
          // check to see if bytes are avaiable to be read from serial port
          int iBytesAvailable = isIn.available();
          if (iBytesAvailable > 0)
          {
            // read available bytes into array
            iBytesRead = isIn.read(baData, 0, 100);
            byte[] baString = new byte[iBytesRead * 2];
            // dump data to screen
            int stringPos = 0;
            for (int i = 0; i < iBytesRead; i++)
            {
              if (EmulatorPane.LEGALCHARS.indexOf(baData[i]) >= 0)
              {
                if (baData[i] == 0x0D)
                {
                  switch (settings.getLineTerminator())
                  {
                    case CRLF:
                      baString[stringPos] = 0x0D;
                      stringPos++;    // fall through
                    case LF:
                      baString[stringPos] = 0x0A;
                      stringPos++;
                      break;
                  }
                }
                else
                {
                  baString[stringPos] = baData[i];
                  stringPos++;
                }
              }
            }
            updateDisplay(new String(baString, 0, stringPos));
            Thread.yield();
          }
        }
        Thread.yield();
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }

  private void updateDisplay(final String updateString) throws InterruptedException, InvocationTargetException
  {
    SwingUtilities.invokeLater(
        new Runnable()
        {
          public void run()
          {
            terminal.append(updateString); 
            terminal.setCaretToEnd();
          }                    
        });
  }
}
