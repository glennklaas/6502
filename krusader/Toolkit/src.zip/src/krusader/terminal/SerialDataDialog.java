package krusader.terminal;

import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import krusader.common.BaseDialog;
import krusader.common.KEGUIUtils;
import krusader.editor.KrusaderSourceDataType;

public class SerialDataDialog extends BaseDialog implements ActionListener
{
  boolean sending = true;
  
  JTextField startAddressField = new JTextField("$2000");
  JTextField endAddressField = new JTextField();
  
  JComboBox formatCombo = null;

  private KrusaderSourceDataType selectedType = KrusaderSourceDataType.HEX;
  SerialDataHandler handler;

  private boolean serialTarget = true;
  
  public SerialDataDialog(SerialDataHandler owner, String title) throws HeadlessException
  {
    super(owner.getParent(), title);
    handler = owner;
    initialise(createMainPane());
  }

  public boolean targetEmulator() { return !serialTarget; }
  
  public KrusaderSourceDataType getFormat()
  {
    return selectedType;
  }

  public int getStartAddress()
  {
    return getAddress(startAddressField);
  }

  public boolean hasEndAddress()
  {
    return endAddressField.getText().trim().length() > 0;
  }

  public int getEndAddress()
  {
    return getAddress(endAddressField);
  }

  public int getNumBytes()
  {
    return getEndAddress() - getStartAddress();
  }

  public boolean isSending() { return sending; }
  public boolean isReceiving() { return !sending; }

  public void showLoadDialog(JFrame parent)
  {
    sending = false;
    setVisible(true);
  }

  public void showSendDialog(JFrame parent)
  {
    sending = true;
    setVisible(true);
  }

  protected JPanel createMainPane()
  {
    // need to specify format and number of bytes (or default for all when sending)
    
    JPanel controls = new JPanel(new GridLayout(5, 2));
    
    controls.add(new JLabel("Format"));
    formatCombo = new JComboBox(KrusaderSourceDataType.values());
    formatCombo.setActionCommand("Format");
    formatCombo.setSelectedItem(selectedType);
    formatCombo.addActionListener(this);
    controls.add(formatCombo);

    controls.add(new JLabel("Start address: "));
    controls.add(startAddressField);
    controls.add(new JLabel("End address:"));
    controls.add(endAddressField);

    ButtonGroup formatGroup = new ButtonGroup();

    JRadioButton button = new JRadioButton("Send");
    button.setActionCommand("Send");
    button.addActionListener(this);
    button.setSelected(sending);
    controls.add(button);
    formatGroup.add(button);

    button = new JRadioButton("Receive");
    button.setActionCommand("Receive");
    button.addActionListener(this);
    button.setSelected(!sending);
    controls.add(button);
    formatGroup.add(button);
    
    button.addChangeListener(new ChangeListener()
    {
      public void stateChanged(ChangeEvent e)
      {
        JRadioButton source = (JRadioButton)e.getSource();
        endAddressField.setEnabled(source.isSelected());
      }
    });

    ButtonGroup targetGroup = new ButtonGroup();

    button = new JRadioButton("Serial");
    button.setActionCommand("Serial");
    button.addActionListener(this);
    button.setSelected(serialTarget);
    controls.add(button);
    targetGroup.add(button);
    
    button.addChangeListener(new ChangeListener()
    {
      public void stateChanged(ChangeEvent e)
      {
        JRadioButton source = (JRadioButton)e.getSource();
        formatCombo.setEnabled(source.isSelected());
      }
    });

    button = new JRadioButton("Emulator");
    button.setActionCommand("Emulator");
    button.addActionListener(this);
    button.setSelected(!serialTarget);
    controls.add(button);
    targetGroup.add(button);
    
    controls.setBorder(new EmptyBorder(5, 5, 5, 5));
    
    return controls;
  }

  protected void doOK()
  {
    // validate settings
    try
    {
      if (sending)
      {
        if (!getFormat().equals(KrusaderSourceDataType.TEXT))
        {
          int startAddress = getStartAddress();
          int endAddress = hasEndAddress() ? getEndAddress() : 0xFFFF;
          
          if (endAddress < startAddress)
            throw new Exception("Invalid range");
        }
      }
      else
      {
        if (getFormat().equals(KrusaderSourceDataType.TEXT))
          throw new Exception("Cannot upload text");
          
        int startAddress = getStartAddress();
        int endAddress = getEndAddress();
        
        if (endAddress < startAddress)
          throw new Exception("Invalid range");
      }
      setVisible(false);
      handler.handleTransfer(this);
    }
    catch (Exception x)
    {
      showError(KEGUIUtils.getParentFrameOrDialog(this), 
          "Transfer settings error: " + x.getMessage(), "Error");
      x.printStackTrace();
    }
  }
  
  private int getAddress(JTextField addressField)
  {
    if (selectedType.equals(KrusaderSourceDataType.TEXT))
      throw new IllegalStateException("No address specification for text data");
    else
    {
      String text = addressField.getText().trim();
      if (text.length() < 0)
        return 0;
      if (text.charAt(0) == '$')
        text = text.substring(1);
      return Integer.parseInt(text, 16);
    }
  }

  public void actionPerformed(ActionEvent e)
  {
    if (e.getActionCommand().equals("Format"))
      selectedType = (KrusaderSourceDataType)((JComboBox)(e.getSource())).getSelectedItem();
    else if (e.getActionCommand().equals("Send"))
      sending = true;
    else if (e.getActionCommand().equals("Receive"))
      sending = false;
    else if (e.getActionCommand().equals("Serial"))
      serialTarget = true;
    else if (e.getActionCommand().equals("Emulator"))
      serialTarget = false;
  }
}
