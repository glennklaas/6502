package krusader.terminal;

import gnu.io.SerialPort;


public enum FlowControl
{
  NONE, HARDWARE, XONXOFF;
  
  public int getAsInt()
  {
	  switch (this)
	  {
	  	case HARDWARE:
	  		return SerialPort.FLOWCONTROL_RTSCTS_IN
	  			& SerialPort.FLOWCONTROL_RTSCTS_OUT;
	  	case XONXOFF:
	  		return SerialPort.FLOWCONTROL_XONXOFF_IN
	  			& SerialPort.FLOWCONTROL_XONXOFF_OUT;
	  	default:
	  	case NONE:
	  		return SerialPort.FLOWCONTROL_NONE;
	  }
  }
}
