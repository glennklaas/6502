package krusader.terminal;

import gnu.io.SerialPort;

public enum StopBits
{
  ONE, ONEPOINTFIVE, TWO;
  
  public int getAsInt()
  {
    switch (this)
    {
      case ONE:
        return SerialPort.STOPBITS_1;
      case ONEPOINTFIVE:
        return SerialPort.STOPBITS_1_5;
      default:
      case TWO:
        return SerialPort.STOPBITS_2;
    }
  }
}
