package krusader.terminal;

public enum EOL
{
  CR, LF, CRLF;
  
  public String asString()
  {
    switch (this)
    {
      case LF:
        return "\n";
      case CRLF:
        return "\r\n";
      case CR:
      default:
        return "\r";
    }
  }
  
  static public EOL fromString(String str)
  {
    if (str.equals(CR.asString()))
      return CR;
    else if (str.equals(LF.asString()))
      return LF;
    else if (str.equals(CRLF.asString()))
      return CRLF;
    throw new IllegalArgumentException(str + " is not a line terminator string");
  }
}
