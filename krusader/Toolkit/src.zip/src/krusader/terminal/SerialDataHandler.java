package krusader.terminal;

import java.io.IOException;
import java.io.StringWriter;

import javax.swing.JOptionPane;

import krusader.common.KEGUIUtils;
import krusader.editor.KrusaderEditor;
import krusader.editor.KrusaderSourceDataType;
import krusader.editor.formats.BinaryData;
import krusader.editor.formats.IntelHexHandler;
import krusader.editor.formats.WozMonitorHexHandler;
import krusader.editor.source.InvalidLineException;
import krusader.editor.source.SourceDocument;

public class SerialDataHandler
{    
  KrusaderEditor parent = null;
  
  public SerialDataHandler(KrusaderEditor parent)
  {
    this.parent = parent;
  }  
  
  public void transfer(KrusaderEditor parent, SerialDataDialog dialog)
  {
    this.parent = parent;

    KEGUIUtils.centerOnParent(parent, dialog);
    dialog.setVisible(true);
  }
  
  public KrusaderEditor getParent() { return parent; }

  public void handleTransfer(SerialDataDialog dialog) throws IOException
  {
    if (dialog.isSending())
      send(parent.createSourceDocument(), dialog);
    else
      receive(dialog);
  }
  
  public void send(SourceDocument doc, SerialDataDialog dialog) throws IOException
  {
    if (doc == null)
      return;
    
    KEGUIUtils.setWaitCursor(parent);
    KrusaderSourceDataType format = dialog.getFormat();

    if (!format.equals(KrusaderSourceDataType.HEX))
    {
      JOptionPane.showMessageDialog(parent, "Format not yet implemented", 
          "Unimplemented", JOptionPane.ERROR_MESSAGE);
      return;
    }
    
    BinaryData sourceData;
    StringWriter writer = new StringWriter();
    try
    {
      switch (format)
      {
        case TEXT:
          // simple text transfer?
          break;
        case BINARY:
          // later XModem?
          break;
        case HEX:
          int startAddress = dialog.getStartAddress();
          sourceData = new BinaryData(startAddress, doc.getTokenized());
          if (dialog.hasEndAddress())
          {
            sourceData.trimData(startAddress, dialog.getEndAddress() - startAddress);
          }
          if (dialog.targetEmulator())
          {
            parent.sendToEmulator(sourceData); 
          }
          else
          {
            new WozMonitorHexHandler().encode(writer, sourceData, 0x08);
            parent.sendData(writer.toString());
          }
          break;
        case INTEL_HEX:
          startAddress = dialog.getStartAddress();
          sourceData = new BinaryData(startAddress, doc.getTokenized());
          if (dialog.hasEndAddress())
          {
            sourceData.trimData(startAddress, dialog.getEndAddress() - startAddress);
          }
          new IntelHexHandler().encode(writer, sourceData, 0x10);
          break;
      }
    }
    catch (Exception x)
    {
      x.printStackTrace();
      JOptionPane.showMessageDialog(parent, x.getMessage(),
          "Source Format Error", JOptionPane.ERROR_MESSAGE);
    }
  }
  
  public void receive(SerialDataDialog dialog) throws IOException
  {
    if (!dialog.targetEmulator())
    {
      JOptionPane.showMessageDialog(parent, "Receive from Replica 1 not yet implemented", 
        "Unimplemented", JOptionPane.ERROR_MESSAGE);
      return;
    }
    
    KEGUIUtils.setWaitCursor(parent);
    
    int start = dialog.getStartAddress();
    BinaryData sourceData = parent.getEmulator().getData(start, dialog.getNumBytes());
    SourceDocument source = null;
    try
    {
      source = new SourceDocument(sourceData.getData(start));
    }
    catch (InvalidLineException x)
    {
      x.printStackTrace();
      JOptionPane.showMessageDialog(parent, x.getMessage(),
          "Source Format Error", JOptionPane.ERROR_MESSAGE);
    }
    
    parent.setSourceDocument(source);
  }
}
