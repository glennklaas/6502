package krusader.terminal;

import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;

import java.awt.Color;
import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.text.AbstractDocument;

import krusader.common.KEGUIUtils;
import krusader.editor.KrusaderEditor;
import krusader.editor.LimitedLinesDocumentFilter;
import krusader.editor.OvertypeCaret;

/**
 * A pane that acts as a serial terminal for the R1
 */
public class TerminalPane extends JTextArea
{
  SerialPort thePort;

  /** The size of the static read buffer. */
  protected static final int BUFSIZE = 1024;
  /** A buffer for the read listener; preallocated once. */
  static byte[] buf = new byte[BUFSIZE];

  /** The state for disconnected and connected */
  static int S_DISCONNECTED = 0, S_CONNECTED = 1;

  /** The state, either disconnected or connected */
  int state = S_DISCONNECTED;

  /** The substate settings */
  static int S_INTERACT = 0, S_XFER = 1;

  /**
   * The online state, either interactive or in xfer. Used by the main reader
   * thread to avoid reading data meant for the xfer program.
   */
  int submode = S_INTERACT;

  private static InputStream serialInput;
  private static OutputStream serialOutput;

  private TerminalReader reader;
  private TerminalWriter writer;
  
  private KrusaderEditor parent;

  private LimitedLinesDocumentFilter docFilter;
  
  private OvertypeCaret caret = new OvertypeCaret()
  {
    public void setVisible(boolean aFlag)
    {
      super.setVisible(true); // always visible
    }
  };

  public TerminalPane(final KrusaderEditor parent)
  {
    super();

    this.parent = parent;
    setEditable(false); // only from the terminal
    setFont(parent.getFont());
    setForeground(Color.GREEN);
    setBackground(Color.BLACK);
    setCaretColor(Color.GREEN);
    caret.setBlinkRate(getCaret().getBlinkRate());
    setCaret(caret);
    caret.setVisible(true);
    
    docFilter = new LimitedLinesDocumentFilter(parent.getTerminalSettings().getLinesToShow());
    ((AbstractDocument)getDocument()).setDocumentFilter(docFilter);

    KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
    manager.addKeyEventDispatcher(new KeyEventDispatcher()
    {
      public boolean dispatchKeyEvent(KeyEvent k)
      {
        if (k.getID() == KeyEvent.KEY_TYPED && parent.isTerminal() &&
            KEGUIUtils.parentFrameHasFocus(TerminalPane.this))
        {
          keyTyped(k);
          TerminalPane.this.requestFocus();
          return true;
        }
        else
        {
          return false;
        }
      }
    });
  }

  /** Connect to the chosen serial port, and set parameters. */
  public void connect(CommPortIdentifier cpi) throws Exception
  {
    TerminalSettings settings = parent.getTerminalSettings();

    try
    {
      // Open the specified serial port
      thePort = (SerialPort)cpi.open("Krusader", 15 * 1000);
    }
    catch (Exception x)
    {
      throw new Exception("Failed to open the serial port");
    }
    
    // Set the serial port parameters.
    thePort.setSerialPortParams(settings.getBaud(), settings.getDatabits(),
        settings.getStopbits().getAsInt(), settings.getParity().getAsInt());

    thePort.setFlowControlMode(settings.getFlow().getAsInt());
    // TODO why and when is this needed?
    thePort.setDTR(true);
    thePort.setRTS(true);
    
    // Similar to "raw" mode: return when 1 or more chars available.
//    try
//    {
//      thePort.enableReceiveThreshold(1);
//      if (!thePort.isReceiveThresholdEnabled())
//      {
//        disconnect();
//        throw new Exception("Could not set receive threshold");
//      }
//      thePort.setInputBufferSize(buf.length);
//    }
//    catch (UnsupportedCommOperationException ev)
//    {
//      disconnect();
//      throw new Exception(
//          "Unable to set receive threshold in Comm API; port unusable.");
//    }

    // Get the streams
    serialInput = thePort.getInputStream();
    serialOutput = thePort.getOutputStream();
    
    // Tell rest of program, and user, that we're online.
    state = S_CONNECTED;
    
    reader = new TerminalReader(serialInput, this, settings);
    writer = new TerminalWriter(serialOutput, this, settings);
    reader.start();
    writer.start();
  }

  /** Break our connection to the serial port. */
  public void disconnect()
  {
    // Tell rest of program we are no longer online.
    state = S_DISCONNECTED;
    
    // Tell java.io we are done with the input and output
    delay(100);

    if (serialInput == null)
    {
      return; // nothing to close
    }
    try
    {
      if (serialInput != null)
      {
        serialInput.close();
        serialInput = null;
      }
      if (serialOutput != null)
      {
        serialOutput.close();
        serialOutput = null;
      }
    }
    catch (IOException e)
    {
      JOptionPane.showMessageDialog(TerminalPane.this.parent,
          "IO Exception closing port:\n" + e.toString(), "Error",
          JOptionPane.ERROR_MESSAGE);
    }
    // Tell javax.comm we are done with the port.
    thePort.removeEventListener();
    thePort.close();
  }

  /** Convenience routine, due to useless InterruptedException */
  public void delay(long milliseconds)
  {
    try
    {
      Thread.sleep(milliseconds);
    }
    catch (InterruptedException e)
    {
    }
  }
  
  public void sendData(String line) 
  {
    if (state != S_CONNECTED) return;
    try
    {
      for (int i = 0; i < line.length(); i++)
      {
        writer.sendData(line.charAt(i));
      }
      Thread.sleep(parent.getTerminalSettings().getLineDelay());
    }
    catch (Exception e)
    {
      e.printStackTrace(System.out);
    }
    state = S_CONNECTED;
  }

  private void keyTyped(KeyEvent ke)
  {
    if (state != S_CONNECTED)
    {
      JOptionPane.showMessageDialog(this, "No connection");
      return;
    }
    
    char c = ke.getKeyChar();
    if (c == '\n')
      writer.sendData('\r');
    else
      writer.sendData(Character.isLowerCase(c) ? Character.toUpperCase(c) : c);
    
    setCaretToEnd();
  }
  
  public void setCaretToEnd()
  {
    setCaretPosition(this.getText().length());
  }

  public void reconnect() throws Exception
  {
    disconnect();
    connect(parent.getTerminalSettings().getPort());
  }

  public boolean isConnected()
  {
    return state == S_CONNECTED;
  }

  public void updateSettings(TerminalSettings termSettings)
  {
    docFilter.setMaxLines((AbstractDocument)getDocument(), termSettings.getLinesToShow());
  }
}