package krusader.terminal;

import gnu.io.SerialPort;

public enum Parity
{
  NONE, EVEN, ODD;
  
  public int getAsInt()
  {
    switch (this)
    {
      case EVEN:
        return SerialPort.PARITY_EVEN;
      case ODD:
        return SerialPort.PARITY_ODD;
      default:
      case NONE:
        return SerialPort.PARITY_NONE;
    }
  }
}
