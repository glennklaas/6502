package krusader.terminal;

import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentLinkedQueue;

public class TerminalWriter extends Thread
{
  // Linked Queue used to handle incoming write requests
  ConcurrentLinkedQueue<Byte> clqData;
  // output stream to SerialPort
  OutputStream osOut = null;

  TerminalSettings settings;
  TerminalPane terminal;
  
  /**
   * Creates a new instance of SerialTestToolWriter
   */
  public TerminalWriter(OutputStream out, TerminalPane terminal, TerminalSettings settings)
  {
    // create Q and register SerialPoertTester and GUI objects
    clqData = new ConcurrentLinkedQueue<Byte>();
    osOut = out;
    this.terminal = terminal;
    this.settings = settings;
    setPriority(Thread.MIN_PRIORITY);
  }
  
  // send data, places data in Linked Q, this is a FIFO Q
  public void sendData(int iData)
  {
    try
    {
      Byte bData = new Byte((byte)iData);
      if (bData != null)
      {
        clqData.add(new Byte((byte)iData));
      }
    }
    catch (Exception e)
    {
      e.printStackTrace(System.out);
    }
  }

  // write thread
  public void run()
  {
    while (terminal.isConnected())
    {
      if (osOut != null)
      {
        // check to see if we are sending a file
        // if not sending file check Linked Q for data to be transmitted
        Byte bData = (Byte)clqData.poll();
        if (bData != null)
        {
          try
          {
            // send data to SerialPort
            osOut.write((byte)bData.intValue());
          }
          catch (IOException ex)
          {
            ex.printStackTrace(System.out);
          }
        }
        terminal.delay(settings.getCharDelay());
      }
    }
  }
}
