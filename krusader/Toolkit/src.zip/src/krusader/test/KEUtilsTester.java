package krusader.test;

import junit.framework.TestCase;
import krusader.common.KEUtils;

public class KEUtilsTester extends TestCase
{
  public void testToHex()
  {
    assertEquals("1234", KEUtils.toHex(0x1234, 4));
    assertEquals("0234", KEUtils.toHex(0x234, 4));
    assertEquals("0034", KEUtils.toHex(0x34, 4));
    assertEquals("0004", KEUtils.toHex(0x4, 4));
    assertEquals("0000", KEUtils.toHex(0x0, 4));

//    assertEquals("1234", KEUtils.toHex(0x1234, 3));
    assertEquals("234", KEUtils.toHex(0x234, 3));
    assertEquals("034", KEUtils.toHex(0x34, 3));
    assertEquals("004", KEUtils.toHex(0x4, 3));

 //   assertEquals("1234", KEUtils.toHex(0x1234, 2));
 //   assertEquals("234", KEUtils.toHex(0x234, 2));
    assertEquals("34", KEUtils.toHex(0x34, 2));
    assertEquals("04", KEUtils.toHex(0x4, 2));
    
//    assertEquals("1234", KEUtils.toHex(0x1234, 1));
//    assertEquals("234", KEUtils.toHex(0x234, 1));
//    assertEquals("34", KEUtils.toHex(0x34, 1));
    assertEquals("4", KEUtils.toHex(0x4, 1));
    
    assertEquals("0001001000110100", KEUtils.toBinary(0x1234, 16));
    assertEquals("0000001000110100", KEUtils.toBinary(0x234, 16));
    assertEquals("0000000000110100", KEUtils.toBinary(0x34, 16));
    assertEquals("0000000000000100", KEUtils.toBinary(0x4, 16));
  }
}
