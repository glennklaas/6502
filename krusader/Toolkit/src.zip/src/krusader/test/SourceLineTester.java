package krusader.test;

import junit.framework.TestCase;
import krusader.editor.source.Directive;
import krusader.editor.source.InvalidLineException;
import krusader.editor.source.Mnemonic;
import krusader.editor.source.SourceLine;

public class SourceLineTester extends TestCase
{
  SourceLine line;
  
  public void testKrusaderFormat()
  {
    try
    {
      line = new SourceLine("LABEL1  SEC ARGS        COMMENT");
      assertEquals("LABEL1", line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertEquals("ARGS", line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine("LABEL  SEC ARGS        COMMENT");
      assertEquals("LABEL", line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertEquals("ARGS", line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine(" SEC ARGS        COMMENT");
      assertNull(line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertEquals("ARGS", line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine(" SEC         COMMENT");
      assertNull(line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertNull(line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine(" SEC         ");
      assertNull(line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertNull(line.getArgs());
      assertNull(line.getComment());
      
      line = new SourceLine(" SEC");
      assertNull(line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertNull(line.getArgs());
      assertNull(line.getComment());
      
      line = new SourceLine("LABEL1  SEC 123456789ABCDE 123456789A");
      assertEquals("LABEL1", line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertEquals("123456789ABCDE", line.getArgs());
      assertEquals("123456789A", line.getComment());
      
      line = new SourceLine("LABEL1XXXXX  SEC 123456789ABCDEXXXXX 123456789ABXXXXX");
      assertEquals("LABEL1", line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertEquals("123456789ABCDE", line.getArgs());
      assertEquals("123456789AB", line.getComment());
      
      line = new SourceLine("LABEL1  .B ARGS        COMMENT");
      assertEquals("LABEL1", line.getLabel());
      assertEquals(Directive.B, line.getDirective());
      assertEquals("ARGS", line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine("R2FLAG  .= $1E");
      assertEquals("R2FLAG", line.getLabel());
      assertEquals(Directive.EQ, line.getDirective());
      assertEquals("$1E", line.getArgs());
      assertNull(line.getComment());
      
      line = new SourceLine("        ");
      assertTrue(line.isBlank());
      
      line = new SourceLine("");
      assertTrue(line.isBlank());
      
      line = new SourceLine("; LONG COMMENT LINE");
      assertTrue(line.isCommentOnly());
      assertEquals("LONG COMMENT LINE", line.getComment());
    }
    catch (InvalidLineException e)
    {
      e.printStackTrace();
      fail(e.getMessage());
    }
  }
  
  public void testGenericFormat()
  {
    try
    {      
      // test funny spacings
      line = new SourceLine("R2FLAG  .=$1E");
      assertEquals("R2FLAG", line.getLabel());
      assertEquals(Directive.EQ, line.getDirective());
      assertEquals("$1E", line.getArgs());
      assertNull(line.getComment());
      
      line = new SourceLine("R2FLAG.= $1E");
      assertEquals("R2FLAG", line.getLabel());
      assertEquals(Directive.EQ, line.getDirective());
      assertEquals("$1E", line.getArgs());
      assertNull(line.getComment());
      
      line = new SourceLine("R2FLAG.=$1E");
      assertEquals("R2FLAG", line.getLabel());
      assertEquals(Directive.EQ, line.getDirective());
      assertEquals("$1E", line.getArgs());
      assertNull(line.getComment());
      
      line = new SourceLine("LABEL1  SEC ARGS        ; COMMENT");
      assertEquals("LABEL1", line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertEquals("ARGS", line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine("LABELXXX  SEC ARGS        COMMENT");
      assertEquals("LABELX", line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertEquals("ARGS", line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine(" SEC ARGS        ; COMMENT");
      assertNull(line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertEquals("ARGS", line.getArgs());
      assertEquals("COMMENT", line.getComment());
      assertEquals("       SEC ARGS           COMMENT", line.toString());

      
      line = new SourceLine("                         ; COMMENT");
      assertTrue(line.isCommentOnly());
      assertNull(line.getLabel());
      assertNull(line.getMnemonic());
      assertNull(line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine(" SEC ; COMMENT");
      assertNull(line.getLabel());
      assertEquals(Mnemonic.SEC, line.getMnemonic());
      assertNull(line.getArgs());
      assertEquals("COMMENT", line.getComment());
      
      line = new SourceLine("LABEL1  .BYTE ARGS        COMMENT");
      assertEquals("LABEL1", line.getLabel());
      assertEquals(Directive.B, line.getDirective());
      assertEquals("ARGS", line.getArgs());
      assertEquals("COMMENT", line.getComment());

      //line = new SourceLine("BS .= $08    ; backspace");
      line = new SourceLine("BS\t.= $08\t; backspace");
      assertEquals("BS", line.getLabel());
      assertEquals(Directive.EQ, line.getDirective());
      assertEquals("$08", line.getArgs());
      assertEquals("BACKSPACE", line.getComment()); 
    }
    catch (InvalidLineException e)
    {
      e.printStackTrace();
      fail(e.getMessage());
    }
  }
  
  public void testCommaBug()
  {
    try
    {
      line = new SourceLine(".LOOP1\tLDA\tROWS-1,X");
      assertEquals(".LOOP1", line.getLabel());
      assertEquals(Mnemonic.LDA, line.getMnemonic());
      assertEquals("ROWS-1,X", line.getArgs());
      assertNull(line.getComment()); 
    }
    catch (InvalidLineException e)
    {
      e.printStackTrace();
      fail(e.getMessage());
    }
  }
  
  public void testCommentOnlyBug()
  {
    try
    {
      line = new SourceLine("\t\t;\tpreserve A");
      assertNull(line.getLabel());
      assertNull(line.getMnemonic());
      assertNull(line.getArgs());
      assertEquals("PRESERVE A", line.getComment()); 
      
      line = new SourceLine("\t; Apple 1 I/O values");
      assertNull(line.getLabel());
      assertNull(line.getMnemonic());
      assertNull(line.getArgs());
      assertEquals("APPLE 1 I/O VALUES", line.getComment());
    }
    catch (InvalidLineException e)
    {
      e.printStackTrace();
      fail(e.getMessage());
    }
  }
  
  public void testTokenising()
  {
    try
    {
      String lineText = "BS     .=  $08";
      line = new SourceLine(lineText);
      assertEquals(new SourceLine(line.tokenise()).getLineText(), lineText);
      
      lineText = "LABEL1 SEC ARGS           COMMENT";
      line = new SourceLine(lineText);
      assertEquals(new SourceLine(line.tokenise()).getLineText(), lineText);
      
      lineText = "MAIN   .M";
      line = new SourceLine(lineText);
      assertEquals(new SourceLine(line.tokenise()).getLineText(), lineText);
    }
    catch (InvalidLineException e)
    {
      e.printStackTrace();
      fail(e.getMessage());
    }
  }
}
