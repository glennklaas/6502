/*
 * Main.java
 *
 * Created on May 14, 2007, 7:34 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package krusader.test;

import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;

import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 *
 * @author Bamse
 */
public class CommTest {
    
    /** Creates a new instance of Main */
    public CommTest() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CommTest daProg = new CommTest();
        daProg.testPorts();
    }
    
    public void testPorts() {
        java.util.Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();
        SerialPort serialPort;
        while ( portEnum.hasMoreElements() ) {
            CommPortIdentifier portIdentifier = (CommPortIdentifier) portEnum.nextElement();
            System.out.println(portIdentifier.getName());
        }
        System.out.println("That's it folks...");
        try {
            CommPortIdentifier portIdentifier = CommPortIdentifier.getPortIdentifier("COM1");
            CommPort commPort = portIdentifier.open(this.getClass().getName(),2000);
            
            if ( commPort instanceof SerialPort ) {
                serialPort = (SerialPort) commPort;
                //serialPort.setSerialPortParams(38400,SerialPort.DATABITS_8,SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
                serialPort.setSerialPortParams(2400,SerialPort.DATABITS_8,SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
                serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
                
                System.out.println("Baud: " + serialPort.getBaudRate());
                System.out.println("Stopbits: " + serialPort.getStopBits());
                System.out.println("Databits: " + serialPort.getDataBits());
                System.out.println("Parity: " + serialPort.getParity());
                System.out.println("Flow: " + serialPort.getFlowControlMode());
                System.out.println("Name: " + serialPort.getName());
                InputStream is = serialPort.getInputStream();
                OutputStream os = serialPort.getOutputStream();
                InputStreamReader isr = new InputStreamReader(is);
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter buw = new BufferedWriter(osw);

                System.out.println("Sending...");
                String command = "F000.F010\r";
                for (char c : command.toCharArray())
                {
                  buw.write(c);
                  System.out.print(c);
                  Thread.sleep(20);
                }
                System.out.println();
                buw.flush();
                
                while (!isr.ready())
                {
                  System.out.println("Waiting...");
                  java.lang.Thread.sleep(200);
                }
                while (isr.ready())
                {
                  System.out.print((char)isr.read());
                  java.lang.Thread.sleep(20);
                }
                System.out.println();
//                if  (isr.ready()) {
//                    System.out.println("got:" + isr.read());
//                } else {
//                    System.out.println("Nothing... As usually...");
//                }
//                System.out.println("Got:" + bur.readLine());
                
                serialPort.close();

            } else {
                System.out.println("Error: Only serial ports are handled by this example.");
                
            }
            
            
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        
    }
}
