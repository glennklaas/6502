package krusader.test;

import junit.framework.TestCase;
import krusader.common.KEUtils;
import krusader.editor.formats.IntelHexHandler;

public class TestIntelHex extends TestCase
{
  public void testCheckSum1()
  {
    String record = ":0300300002337A1E";
    int checksum = IntelHexHandler.calcRecordChecksum(record); 
    assertEquals(0x1E, checksum);
  }
  
  public void testCheckSum2()
  {
    String record = ":10610000A91F8D03C0A90B8D02C0A90385F8A92082";
    int checksum = IntelHexHandler.calcRecordChecksum(record); 
    System.out.println(checksum + "\t" + KEUtils.toHex(checksum, 2));
    assertEquals(0x82, checksum);
  }
  
  public void testCheckSum3()
  {
    String record = ":10201000013E243038014241434B53504143450077";
    int checksum = IntelHexHandler.calcRecordChecksum(record); 
    System.out.println(checksum + "\t" + KEUtils.toHex(checksum, 2));
    assertEquals(0x77, checksum);
  }
  
  public void testCheckSum4()
  {
    String record = ":102020005350013E24323001535041434500435246";
    int checksum = IntelHexHandler.calcRecordChecksum(record); 
    System.out.println(checksum + "\t" + KEUtils.toHex(checksum, 2));
    assertEquals(0x46, checksum);
  }
  
  public void testCheckSum5()
  {
    String record = ":10F00000A90385F8A92085FFA97C85F9A21BBD74F9";
    int checksum = IntelHexHandler.calcRecordChecksum(record); 
    System.out.println(checksum + "\t" + KEUtils.toHex(checksum, 2));
    assertEquals(0xF9, checksum);
  }
}
