package krusader.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import junit.framework.TestCase;
import krusader.editor.formats.BinaryData;
import krusader.editor.formats.WozMonitorHexHandler;

public class WozEncoderTester extends TestCase
{
  public void testRoundTrip()
  {
    try
    {
      WozMonitorHexHandler handler = new WozMonitorHexHandler();
      
      int address = 0;
      ArrayList<Byte> data = null;
      BinaryData sourceData = new BinaryData(address, data);
      handler.encode(new OutputStreamWriter(new ByteArrayOutputStream()), sourceData, 0x10);
    }
    catch (IOException e)
    {
      e.printStackTrace();
      fail(e.getMessage());
    }
  }
}
