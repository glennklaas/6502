package krusader.emulator.apple1;

import java.io.File;
import java.io.FileInputStream;

import krusader.emulator.EmulatorSettings;

public class Memory
{
  public static final int KBD = 0xD010;
  public static final int KBDCR = 0xD011;
  public static final int DSP = 0xD012;
  public static final int DSPCR = 0xD013;
  private EmulatorSettings settings;
  private int mem[];
  private Pia6820 pia;

  public Memory(Pia6820 pia, EmulatorSettings settings)
  {
    mem = new int[0x10000];
    this.pia = pia;
    this.settings = settings;
    reset();
  }

  public int read(int address)
  {
    if (address == DSPCR) 
      return pia.readDspCr();
    else if (address == DSP) 
      return pia.readDsp();
    else if (address == KBDCR) 
      return pia.readKbdCr();
    else if (address == KBD)
      return pia.readKbd();
    else
      return mem[address];
  }

  public void write(int address, int value)
  {
    if (address == DSPCR)
    {
      mem[address] = value;
      pia.writeDspCr(value);
      return;
    }
    if (address == DSP)
    {
      mem[address] = value;
      pia.writeDsp(value);
      return;
    }
    if (address == KBDCR)
    {
      mem[address] = value;
      pia.writeKbdCr(value);
      return;
    }
    if (address == KBD)
    {
      mem[address] = value;
      pia.writeKbd(value);
      return;
    }
   
    int romStart = settings.rom8k ? 0xE000 : 0xFF00; 
    if (address >= romStart && !settings.writeInRom) 
      return;
    
    if (settings.ram8k && address >= 0x2000 && address < romStart)
    {
      return;
    }
    else
    {
      mem[address % 0x10000] = value;
      return;
    }
  }

  public void reset()
  {
    for (int i = 0; i < 0x10000; i++)
      mem[i] = 0;

    loadRom();
  }

  public int[] dumpMemory(int start, int end)
  {
    int fbrut[] = new int[(end - start) + 1];
    for (int i = 0; i < (end - start) + 1; i++)
      fbrut[i] = mem[start + i] & 0xff;

    return fbrut;
  }

  public void loadRom()
  {
    String filename;
    int startingAddress;
    filename = System.getProperty("user.dir") + "/bios/"
        + System.getProperty("ROMFILE", settings.use65C02 ? "65C02.rom.bin" : "6502.rom.bin");
    FileInputStream fis = null;
    try
    {
      File romFile = new File(filename);
      fis = new FileInputStream(romFile);
      long romsize = romFile.length();
      startingAddress = (int)(0x10000 - romsize);
      for (int i = startingAddress; i < 0x10000; i++)
        mem[i] = fis.read();
      fis.close();
    }
    catch (Exception e)
    {
      System.out.println(e);
    }
  }
}
