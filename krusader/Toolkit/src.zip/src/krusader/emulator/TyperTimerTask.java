// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ClipboardHandler.java

package krusader.emulator;

import java.util.TimerTask;

import krusader.emulator.apple1.Keyboard;

class TyperTimerTask extends TimerTask
{
  private EmulatorPane gui;

  String data;
  int i;

  TyperTimerTask(String data, EmulatorPane gui)
  {
    this.data = data;
    this.gui = gui;
  }

  public void sendNextCharacter()
  {
      char key = data.charAt(i++);
      gui.getPIA().writeKbd(Keyboard.kbdTranslator(key));
      gui.getPIA().writeKbdCr(0xA7);

      while (!gui.getPIA().isReadyForInput())
      {
        Thread.yield();
      }
      
      if (i == data.length())
      {
        if (gui != null)
          gui.synchronise(true);
        cancel();
      }
  }

  public void run()
  {
    sendNextCharacter();
    Thread.yield(); // give the GUI a chance to update
  }
}
