package krusader.emulator;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.Timer;

import krusader.emulator.apple1.Pia6820;

public class ClipboardHandler
{
  EmulatorPane gui;
  static Timer theTimer = new Timer();

  public ClipboardHandler(EmulatorPane theGui)
  {
    gui = theGui;
  }

  public void sendDataToApple1(Pia6820 pia)
  {
    if (pia.getKbdInterrups())
    {
      gui.synchronise(false);
      String data = getClipboardContents();
      TyperTimerTask typerTask = new TyperTimerTask(data, gui);
      theTimer.schedule(typerTask, 1, 1);
    }
  }

  public static String getClipboardContents()
  {
    String data = "";
    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
    Transferable contents = clipboard.getContents(null);
    boolean hasTransferableText = contents != null
        && contents.isDataFlavorSupported(DataFlavor.stringFlavor);
    if (hasTransferableText)
    {
      try
      {
        data = (String)contents.getTransferData(DataFlavor.stringFlavor);
      }
      catch (UnsupportedFlavorException ex)
      {
        System.out.println(ex);
      }
      catch (IOException ex)
      {
        System.out.println(ex);
      }
    }
    return data;
  }
}
