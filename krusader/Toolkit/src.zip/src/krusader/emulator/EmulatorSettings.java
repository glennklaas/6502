package krusader.emulator;

public class EmulatorSettings
{
  public boolean writeInRom = false;
  public int terminalSpeed = 60;
  public int freqKHz = 1000;
  public int synchroCycles = 60;
  public int cyclesBeforeSynchro = freqKHz * synchroCycles;
  public int linesToShow = 1000;
  public boolean synchronised = true;
  public boolean ram8k = false;
  public boolean rom8k = true;
  public boolean use65C02 = System.getProperty("65C02", "N").equalsIgnoreCase("Y");;
  
  public void update(EmulatorSettings emulatorSettings)
  {
    freqKHz = emulatorSettings.freqKHz;
    ram8k = emulatorSettings.ram8k;
    rom8k = emulatorSettings.rom8k;
    synchroCycles = emulatorSettings.synchroCycles;
    synchronised = emulatorSettings.synchronised;
    terminalSpeed = emulatorSettings.terminalSpeed;
    writeInRom = emulatorSettings.writeInRom; 
    cyclesBeforeSynchro = freqKHz * synchroCycles;
    use65C02 = emulatorSettings.use65C02;
    linesToShow = emulatorSettings.linesToShow;
  }

  public static EmulatorSettings createReplica1Default()
  {
    return new EmulatorSettings();
  }
}
