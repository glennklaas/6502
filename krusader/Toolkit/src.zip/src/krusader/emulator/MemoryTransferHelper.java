package krusader.emulator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

import krusader.common.KEGUIUtils;
import krusader.editor.KrusaderSourceDataType;
import krusader.editor.formats.BinaryData;
import krusader.editor.formats.IntelHexHandler;
import krusader.editor.formats.WozMonitorHexHandler;

public class MemoryTransferHelper
{    
  JFrame parent = null;
  MemoryDataChooser fileChooser = null;
  
  public MemoryTransferHelper(JFrame parent, MemoryDataChooser mdc)
  {
    this.parent = parent;
    this.fileChooser = mdc;
    mdc.setFileFilter(new MemoryDataFileFilter());
  }
  
  public void saveMemory(EmulatorPane emulatorPane) throws IOException
  {    
    if (fileChooser.showSaveDialog(parent) == JFileChooser.CANCEL_OPTION)
      return;

    int address = fileChooser.getAddress(); 
    int nBytes = fileChooser.getNumBytes();
    BinaryData memoryData = emulatorPane.getData(address, nBytes);
    
    if (memoryData == null)
      return;
    
    KEGUIUtils.setWaitCursor(parent);
    File dataFile = fileChooser.getSelectedFile();
    MemoryDataType format = fileChooser.getFileType();
    
    FileOutputStream fos = null;
    BufferedWriter bw = null;

    try
    {
      switch (format)
      {
        case BINARY:
          fos = new FileOutputStream(dataFile);
          if (memoryData.getAddresses().size() != 1)
            throw new Exception("Invalid data format for binary save");
          ArrayList<Byte> data = memoryData.getData(address);
          byte [] primitiveByteArray = new byte[data.size()];
          int i = 0;
          for (Byte b : data)
            primitiveByteArray[i++] = b;
          fos.write(primitiveByteArray);
          break;
        case HEX:
          new WozMonitorHexHandler().encode(new OutputStreamWriter(new FileOutputStream(dataFile)), memoryData, 0x10);
          break;
        case INTEL_HEX:
          new IntelHexHandler().encode(new OutputStreamWriter(new FileOutputStream(dataFile)), memoryData, 0x10);
          break;
      }
    }
    catch (Exception x)
    {
      x.printStackTrace();
      JOptionPane.showMessageDialog(parent, x.getMessage(),
          "Source Format Error", JOptionPane.ERROR_MESSAGE);
    }
    if (bw != null) bw.close();
    if (fos != null) fos.close();
  }
  
  public BinaryData loadMemory() throws IOException
  {
    if (fileChooser.showOpenDialog(parent) == JFileChooser.CANCEL_OPTION)
      return null;

    KEGUIUtils.setWaitCursor(parent);
    File dataFile = fileChooser.getSelectedFile();
    KrusaderSourceDataType format = 
      KrusaderSourceDataType.fromExtension(fileChooser.getSelectedFileExtension());
        
    FileInputStream fis = null;
    BufferedReader br = null;
    BinaryData memoryData = null;
    
    try
    {
      switch (format)
      {
        case BINARY:
          fis = new FileInputStream(dataFile);
          int dataSize = (int)dataFile.length();  // conversion is ok here - files never that big
          ArrayList<Byte> data = new ArrayList<Byte>(dataSize);
          byte [] buffer = new byte[dataSize];
          fis.read(buffer, 0, dataSize);
          for (byte b : buffer)
          {
            data.add(b);
          }
          memoryData = new BinaryData(fileChooser.getAddress() , data);
          break;
        case HEX:
          memoryData = new WozMonitorHexHandler().decode(new InputStreamReader(new FileInputStream(dataFile)));
          break;
        case INTEL_HEX:
          memoryData = new IntelHexHandler().decode(new InputStreamReader(new FileInputStream(dataFile)));
          break;
      }
    }
    catch (Exception x)
    {
      JOptionPane.showMessageDialog(parent, x.getMessage(),
          "Source Format Error", JOptionPane.ERROR_MESSAGE);
    }
    if (br != null) br.close();
    if (fis != null) fis.close();
    
    return memoryData;
  }
  
  public class MemoryDataFileFilter extends FileFilter
  {
    public boolean accept (File f)
    {
      String extension = f.getName().substring(f.getName().lastIndexOf('.') + 1);
      return f.isDirectory() || KrusaderSourceDataType.isAllowedExtension(extension);
    }
  
    public String getDescription()
    {
      StringBuffer desc = new StringBuffer();
      for (String ext : MemoryDataType.getAllowedExtensions())
        desc.append("; *." + ext);
      return "Memory data (" + desc.substring(2) + ")";
    }
  }
}
