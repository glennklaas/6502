package krusader.emulator;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.filechooser.FileSystemView;

public class MemoryDataChooser extends JFileChooser
{ 
  JPanel formatPanel;
  ButtonGroup formatGroup = new ButtonGroup();
  JTextField addressField = new JTextField("$nnnn");
  JTextField bytesField = new JTextField();
  
  MemoryDataType selectedType = MemoryDataType.HEX;
  private boolean saving;
  
  public MemoryDataChooser()
  {
    this((File)null, (FileSystemView)null);
  }
  
  public MemoryDataChooser(File currentDirectory)
  {
    this(currentDirectory, (FileSystemView)null);
  }

  public MemoryDataChooser(File currentDirectory, FileSystemView fsv)
  {
    super(currentDirectory, fsv);
    createFormatPanel();
    this.setAccessory(formatPanel);
  }

  public MemoryDataChooser(String currentDirectoryPath, FileSystemView fsv)
  {
    super(currentDirectoryPath, fsv);
    createFormatPanel();
    this.setAccessory(formatPanel);
  }
  
  private void createFormatPanel()
  {
    formatPanel = new JPanel(new GridLayout(7 + MemoryDataType.values().length, 1));
    
    formatPanel.add(new JLabel(""));
    formatPanel.add(new JLabel("Choose format: "));
    
    for (MemoryDataType format : MemoryDataType.values())
    {
      JRadioButton button = new JRadioButton(format.toString());
      button.setActionCommand(format.toString());
      button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          selectedType = MemoryDataType.valueOf(e.getActionCommand());
          fixExtension();
          addressField.setEnabled(saving || selectedType.equals(MemoryDataType.BINARY));
        }
      });
      formatPanel.add(button);
      formatGroup.add(button);
    }
    formatPanel.add(new JLabel("Address:"));
    formatPanel.add(addressField);
    formatPanel.add(new JLabel("Num bytes:"));
    formatPanel.add(bytesField);
    formatPanel.add(new JLabel(""));
    
    formatPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
    setFileType(selectedType);
  }
  
  public String getSelectedFileExtension()
  {
    File f = getSelectedFile();
    if (f == null)
      return null;
    String fileName = f.getName();
    int extensionStart = fileName.lastIndexOf('.') + 1;
    if (extensionStart < 0)
      return "";
    else
      return fileName.substring(extensionStart);   
  }

  private void fixExtension()
  {
    File f = getSelectedFile();
    if (f == null)
      return;
    String fileName = f.getName();
    int extensionStart = fileName.lastIndexOf('.') + 1;
    if (extensionStart < 0)
      extensionStart = fileName.length() - 1;
    String extension = fileName.substring(extensionStart);
    String requiredExtension = selectedType.toExtension(); 
    if (!requiredExtension.equals(extension))
    {
      String fixedName = fileName.substring(0, extensionStart) + requiredExtension;
      setSelectedFile(new File(fixedName));
    }
  }
  
  public MemoryDataType getFileType()
  {
    return MemoryDataType.valueOf(formatGroup.getSelection().getActionCommand());
  }
  
  public void setFileType(MemoryDataType type)
  {
    Enumeration<AbstractButton> buttonIt = formatGroup.getElements();
    while (buttonIt.hasMoreElements())
    {
      AbstractButton button = buttonIt.nextElement();
      if (button.getActionCommand().equals(type.toString()))
      {
        button.setSelected(true);
      }
    }
  }
  
  public int getAddress()
  {
    String text = addressField.getText().trim();
    if (text.length() < 0)
      return 0;
    if (text.charAt(0) == '$')
      return Integer.parseInt(text.substring(1), 16);
    else
      return Integer.parseInt(text, 10);
  }
  
  public int getNumBytes()
  {
    String text = bytesField.getText().trim();
    if (text.length() < 0)
      return 0;
    if (text.charAt(0) == '$')
      return Integer.parseInt(text.substring(1), 16);
    else
      return Integer.parseInt(text, 10);
  }

  public int showOpenDialog(Component parent) throws HeadlessException
  {
    addressField.setEnabled(selectedType.equals(MemoryDataType.BINARY));
    bytesField.setEnabled(false);
    saving = false;
    return super.showOpenDialog(parent);
  }

  public int showSaveDialog(Component parent) throws HeadlessException
  {
    addressField.setEnabled(true);
    bytesField.setEnabled(true);
    saving = true;
    return super.showSaveDialog(parent);
  }
}
