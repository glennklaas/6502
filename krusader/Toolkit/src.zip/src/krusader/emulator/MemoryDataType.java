package krusader.emulator;

public enum MemoryDataType
{
  BINARY, INTEL_HEX, HEX;
  
  static String [] extensions = { "bin", "ihex", "hex", "txt" };
  
  static String [] getAllowedExtensions()
  {
    return extensions;
  }
  
  static public boolean isAllowedExtension(String extension)
  {
    try
    {
      fromExtension(extension);
      return true;
    }
    catch (IllegalArgumentException iax)
    {
      return false;
    }
  }
  
  static public MemoryDataType fromExtension(String extension)
  {
    if (extension.equals("bin"))
      return BINARY;
    else if (extension.equals("ihex"))
      return INTEL_HEX;
    else if (extension.equals("hex"))
      return HEX;
    else if (extension.equals("txt"))
      return HEX;
    else
      throw new IllegalArgumentException("Unknown type: " + extension);
  }
  
  public String toExtension()
  {
    switch (this)
    {
      case BINARY:
        return "bin";
      case INTEL_HEX:
        return "ihex";
      case HEX:
        return "hex";
      default:
        return "???";
    }
  }
}
