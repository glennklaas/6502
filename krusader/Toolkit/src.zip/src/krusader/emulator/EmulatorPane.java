package krusader.emulator;

import java.awt.Color;
import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.InputMap;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.text.AbstractDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.Utilities;

import krusader.common.KEGUIUtils;
import krusader.editor.KrusaderEditor;
import krusader.editor.LimitedLinesDocumentFilter;
import krusader.editor.OvertypeCaret;
import krusader.editor.formats.BinaryData;
import krusader.emulator.apple1.Keyboard;
import krusader.emulator.apple1.M65C02;
import krusader.emulator.apple1.Memory;
import krusader.emulator.apple1.Pia6820;

/*
 * Make paste and copy work properly
 * Disable cut
 * Load and save memory action (support binary, woz hex and intel hex formats)
 * 
 * Bug in focus handling - must make pane reclaim focus properly
 */

public class EmulatorPane extends JTextArea
{
  public static final String LEGALCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@!?#$%^&*()_-+=[];:'\",.<>/\\ \n\r";

  private KrusaderEditor parent;

  private LimitedLinesDocumentFilter docFilter;

  private long lastTime;
  private boolean loggingOutput;

  private Memory mem;
  private M65C02 micro;
  private Pia6820 pia;
  private Keyboard keyboard;
  
  private OvertypeCaret caret = new OvertypeCaret('@')
  {
    public void setVisible(boolean aFlag)
    {
      super.setVisible(true); // always visible
    }
  };

  private ClipboardHandler clipboardHandler;

  public EmulatorPane(final KrusaderEditor parent)
  {
    super();

    this.parent = parent;
    setEditable(false);
    setFont(parent.getFont());
    setForeground(Color.GREEN);
    setBackground(Color.BLACK);
    setCaretColor(Color.GREEN);
    caret.setBlinkRate(getCaret().getBlinkRate());
    setCaret(caret);
    caret.setVisible(true);
    getLineCount();

    docFilter = new LimitedLinesDocumentFilter(parent.getEmulatorSettings().linesToShow);
    ((AbstractDocument)getDocument()).setDocumentFilter(docFilter);
    
    KeyboardFocusManager manager = KeyboardFocusManager
        .getCurrentKeyboardFocusManager();
    manager.addKeyEventDispatcher(new KeyEventDispatcher()
    {
      public boolean dispatchKeyEvent(KeyEvent k)
      {
        if (k.getID() == KeyEvent.KEY_TYPED && parent.isEmulator()
            && KEGUIUtils.parentFrameHasFocus(EmulatorPane.this))
        {
          keyTyped(k);
          EmulatorPane.this.requestFocus();
          return true;
        }
        else
        {
          return false;
        }
      }
    });
    
    clipboardHandler = new ClipboardHandler(this);

    InputMap inputMap = getInputMap();
    KeyStroke key = KeyStroke.getKeyStroke((char)KeyEvent.VK_V, InputEvent.CTRL_DOWN_MASK);
    inputMap.put(key, this.parent.getPasteAction());
    
    lastTime = System.currentTimeMillis();
    loggingOutput = false;

    initApple1();
  }

  Pia6820 getPIA()
  {
    return pia;
  }

  M65C02 getMicro()
  {
    return micro;
  }

  Keyboard getKeyboard()
  {
    return keyboard;
  }

  Memory getMemory()
  {
    return mem;
  }

  private void initApple1()
  {
    pia = new Pia6820(this);
    mem = new Memory(pia, parent.getEmulatorSettings());
    micro = new M65C02(mem, parent.getEmulatorSettings());
    micro.start();
  }

  public void synchronise(boolean sync)
  {
    if (parent.getEmulatorSettings().synchronised != sync)
    {
      parent.getEmulatorSettings().synchronised = sync;
    }
  }

  public void handleChar(char c)
  {
    // TODO make this System aware
    if (c == '\r') c = '\n';
    if (Character.isLowerCase(c)) c = Character.toUpperCase(c);
    if (LEGALCHARS.indexOf(c) >= 0)
    {
      this.append("" + (Character.isLowerCase(c) ? Character.toUpperCase(c) : c));
      setCaretPosition(getText().length());
    }

    int selStart = getSelectionStart();
    try
    {
      if (selStart - Utilities.getRowStart(this, getSelectionStart()) == 40)
        this.append("\n");
    }
    catch (BadLocationException e)
    {
      e.printStackTrace();
    }

    if (loggingOutput) System.out.print(c);
    synchronizeOutput();
  }

  public void softReset()
  {
    pia.reset();
    micro.reset();
  }

  public void hardReset()
  {
    micro.stop();
    initApple1();
  }

  private void synchronizeOutput()
  {
    int sleepMillis = (int)((long)(1000 / parent.getEmulatorSettings().terminalSpeed) - 
        (System.currentTimeMillis() - lastTime));
    if (sleepMillis > 0)
    {
      try
      {
        if (parent.getEmulatorSettings().synchronised) 
          Thread.sleep(sleepMillis);
      }
      catch (Exception e)
      {
        System.out.println(e);
      }
    }
    lastTime = System.currentTimeMillis();
  }

  public void keyTyped(KeyEvent e)
  {
    if (pia.getKbdInterrups())
    {
      handleKeyEntry(Keyboard.kbdTranslator(e));
    }
  }

  public void handleKeyEntry(int key)
  {
    if (key != -1)
    {
      pia.writeKbd(key);
      pia.writeKbdCr(0xA7);
    }
  }

  public void receiveData(BinaryData data)
  {
    for (int address : data.getData().keySet())
    {
      ArrayList<Byte> bytes = data.getData(address);
      for (Byte b : bytes)
        mem.write(address++, b >= 0 ? b : 0x0100 + b);
    }
  }

  public BinaryData getData(int address, int bytes)
  {
    BinaryData data = new BinaryData();
    ArrayList<Byte> chunk = new ArrayList<Byte>(bytes);
    for (int i = 0; i < bytes; ++i)
      chunk.add((byte)mem.read(address + i));
    data.setData(address, chunk);
    return data;
  }

  public void typeFromClipboard()
  {
    clipboardHandler.sendDataToApple1(pia);
  }

  public void updateSettings(EmulatorSettings emulatorSettings)
  {
    EmulatorSettings settings = parent.getEmulatorSettings();
    boolean was65C02 = settings.use65C02;
    settings.update(emulatorSettings);
    synchronise(settings.synchronised);
    if (was65C02 != settings.use65C02) // CPU changed
      mem.loadRom();
    docFilter.setMaxLines((AbstractDocument)getDocument(), emulatorSettings.linesToShow);
  }
}