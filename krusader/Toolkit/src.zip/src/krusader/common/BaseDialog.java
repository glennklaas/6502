package krusader.common;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;

public abstract class BaseDialog extends JDialog
{
  public BaseDialog(JFrame owner, String title) throws HeadlessException
  {
    super(owner, title);
 }

  protected void initialise(JPanel mainPanel)
  {
    this.getContentPane().setLayout(new BorderLayout());
    this.getContentPane().add(mainPanel, BorderLayout.CENTER);
    this.getContentPane().add(createButtonPane(), BorderLayout.SOUTH);
    this.pack();
  }
  
  abstract protected JPanel createMainPane();
  
  protected JPanel createButtonPane()
  {
    JPanel p = new JPanel();
    
    JButton okButton = new JButton("OK");
    okButton.setActionCommand("OK");
    okButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        doOK();
      }
    });

    JRootPane rp = getRootPane();
    rp.setDefaultButton(okButton);

    KeyStroke cancel = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0);
    rp.registerKeyboardAction(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          setVisible(false);
        }
      }, cancel, JComponent.WHEN_IN_FOCUSED_WINDOW);

    JButton cancelButton = new JButton("Cancel");
    cancelButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        doCancel();
      }
    });
    
    int strutWidth = 16;

    p.add(Box.createHorizontalStrut(strutWidth));
    p.add(okButton);
    p.add(Box.createHorizontalStrut(strutWidth));
    p.add(cancelButton);
    p.add(Box.createHorizontalStrut(strutWidth));

    p.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

    return p;
  }


  protected void doCancel()
  {
    setVisible(false); 
  }

  abstract protected void doOK();

  static public void showError(Component parentFrame, String message, String title)
  {
    JOptionPane.showMessageDialog(parentFrame, message, title, JOptionPane.ERROR_MESSAGE);
  }
}
