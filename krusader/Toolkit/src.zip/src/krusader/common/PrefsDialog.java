package krusader.common;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import krusader.editor.KrusaderEditor;
import krusader.emulator.EmulatorSettings;
import krusader.terminal.EOL;
import krusader.terminal.FlowControl;
import krusader.terminal.Parity;
import krusader.terminal.StopBits;
import krusader.terminal.TerminalSettings;

public class PrefsDialog extends BaseDialog implements ActionListener
{
  protected KrusaderEditor parent;

  private TerminalSettings termSettings;
  private TerminalSettings tempSettings;
  private EmulatorSettings emuSettings;
  private EmulatorSettings tempEmuSettings;

  private JTextField lineDelayField = new JTextField("200");
  private JTextField charDelayField = new JTextField("20");
  
  private JTextField termSpeedField = new JTextField("60");
  private JTextField freqField = new JTextField("1000");
  private JTextField syncCyclesField = new JTextField("60");

  private JTextField terminalLinesField = new JTextField("1000");
  private JTextField emulatorLinesField = new JTextField("1000");

  private JComboBox portCombo;
  private JComboBox speedCombo;
  private JComboBox parityCombo;
  private JComboBox flowCombo;
  private JComboBox stopCombo;
  private JComboBox bitsCombo;

  private JCheckBox writeRomCheck;

  private JCheckBox rom8kCheck;

  private JCheckBox ram8kCheck;

  private JCheckBox use65C02Check;
  
  public PrefsDialog(KrusaderEditor owner, String title) throws HeadlessException
  {
    super(owner, title);
    parent = owner;
    termSettings = TerminalSettings.createReplica1Default();
    tempSettings = TerminalSettings.createReplica1Default();
    emuSettings = tempEmuSettings = new EmulatorSettings();
    initialise(createMainPane());
    this.setResizable(false);
  }

  protected JPanel createMainPane()
  {    
    JPanel controlPanel = new JPanel(new BorderLayout());
    controlPanel.add(createEmulatorControlsPane(), BorderLayout.NORTH);
    controlPanel.add(createTerminalControlsPane(), BorderLayout.CENTER);
    return controlPanel;
  }
  
  private Component createEmulatorControlsPane()
  {
    JPanel emulatorControls = new JPanel(new GridLayout(4, 4, 10, 2));
    
    emulatorControls.add(new JLabel("Freq (kHz)"));    
    emulatorControls.add(freqField);
    
    emulatorControls.add(new JLabel("Terminal speed (Hz)"));
    emulatorControls.add(termSpeedField);

    emulatorControls.add(new JLabel("Sync cycles"));
    emulatorControls.add(syncCyclesField);

    emulatorControls.add(new JLabel("Emulator history lines"));
    emulatorControls.add(emulatorLinesField);
    
    writeRomCheck = new JCheckBox("Write in ROM");
    writeRomCheck.setActionCommand("ROM");
    writeRomCheck.addActionListener(this);
    emulatorControls.add(writeRomCheck);
    
    rom8kCheck = new JCheckBox("8K ROM");
    rom8kCheck.setActionCommand("8KROM");
    rom8kCheck.addActionListener(this);
    emulatorControls.add(rom8kCheck);
    
    ram8kCheck = new JCheckBox("8K RAM");
    ram8kCheck.setActionCommand("8KRAM");
    ram8kCheck.addActionListener(this);
    emulatorControls.add(ram8kCheck);
    
    use65C02Check = new JCheckBox("Use 65C02");
    use65C02Check.setActionCommand("65C02");
    use65C02Check.addActionListener(this);
    emulatorControls.add(use65C02Check);

    JButton button = new JButton("Defaults");
    button.setActionCommand("EMUDEF");
    button.addActionListener(this);
    emulatorControls.add(button);

    emulatorControls.add(new JLabel(""));
    emulatorControls.add(new JLabel(""));
    emulatorControls.add(new JLabel(""));
    
    emulatorControls.setBorder(BorderFactory.createTitledBorder(
        BorderFactory.createLineBorder(new Color(153, 153, 153), 2),
        "Emulator Settings"));
    
    updateEmulatorValues(emuSettings);
    
    return emulatorControls;
  }

  private JPanel createTerminalControlsPane()
  {
    JPanel terminalControls = new JPanel(new GridLayout(6, 4, 10, 2));
    
    terminalControls.add(new JLabel("Port"));
    portCombo = new JComboBox(TerminalSettings.getPorts());
    portCombo.setActionCommand("Port");
    portCombo.addActionListener(this);
    terminalControls.add(portCombo);

    terminalControls.add(new JLabel("Speed"));
    speedCombo = new JComboBox(new Integer[] { 2400, 9600, 19200, 38400 });
    speedCombo.setActionCommand("Speed");
    speedCombo.addActionListener(this);
    terminalControls.add(speedCombo);

    terminalControls.add(new JLabel("Parity"));
    parityCombo = new JComboBox(Parity.values());
    parityCombo.setActionCommand("Parity");
    parityCombo.addActionListener(this);
    terminalControls.add(parityCombo);

    terminalControls.add(new JLabel("Flow control"));
    flowCombo = new JComboBox(FlowControl.values());
    flowCombo.setActionCommand("Flow");
    flowCombo.addActionListener(this);
    terminalControls.add(flowCombo);

    terminalControls.add(new JLabel("Stop bits"));
    stopCombo = new JComboBox(new Double[] { 1.0, 1.5, 2.0 });
    stopCombo.setActionCommand("Stop");
    stopCombo.addActionListener(this);
    terminalControls.add(stopCombo);

    terminalControls.add(new JLabel("Data bits"));
    bitsCombo = new JComboBox(new Integer[] { 7, 8 });
    bitsCombo.setActionCommand("Data");
    bitsCombo.addActionListener(this);
    terminalControls.add(bitsCombo);

    terminalControls.add(new JLabel("Char delay (ms)"));
    terminalControls.add(charDelayField);
    terminalControls.add(new JLabel("Line delay (ms)"));
    terminalControls.add(lineDelayField);

    terminalControls.add(new JLabel("Terminal history lines"));
    terminalControls.add(terminalLinesField);
    terminalControls.add(new JLabel(""));
    terminalControls.add(new JLabel(""));
    
    updateTerminalValues(termSettings);
    
    JButton button;
    terminalControls.add(new JLabel("Defaults:"));
    
    button = new JButton("Replica 1");
    button.setActionCommand("REPLICA1");
    button.addActionListener(this);
    terminalControls.add(button);

    button = new JButton("ACIA");
    button.setActionCommand("ACIA");
    button.addActionListener(this);
    terminalControls.add(button);
    
    terminalControls.setBorder(BorderFactory.createTitledBorder(
        BorderFactory.createLineBorder(new Color(153, 153, 153), 2),
        "Terminal Settings"));
    
    return terminalControls;
  }

  private void updateTerminalValues(TerminalSettings updateSettings)
  {
    bitsCombo.setSelectedItem(updateSettings.getDatabits());
    stopCombo.setSelectedItem(updateSettings.getStopbits());
    flowCombo.setSelectedItem(updateSettings.getFlow());
    parityCombo.setSelectedItem(updateSettings.getParity());
    speedCombo.setSelectedItem(updateSettings.getBaud());
    portCombo.setSelectedItem(updateSettings.getPortName());
    charDelayField.setText(updateSettings.getCharDelay() + "" );
    lineDelayField.setText(updateSettings.getLineDelay() + "" );
    terminalLinesField.setText(updateSettings.getLinesToShow() + "" );
  }

  private void updateEmulatorValues(EmulatorSettings updateSettings)
  {
    freqField.setText(updateSettings.freqKHz + "" );
    termSpeedField.setText(updateSettings.terminalSpeed + "" );
    syncCyclesField.setText(updateSettings.synchroCycles + "" );
    writeRomCheck.setSelected(updateSettings.writeInRom);
    rom8kCheck.setSelected(updateSettings.rom8k);
    ram8kCheck.setSelected(updateSettings.ram8k);
    use65C02Check.setSelected(updateSettings.use65C02);
    terminalLinesField.setText(updateSettings.linesToShow + "" );
  }
  
  protected void doOK()
  {
    try
    {
      tempSettings.setCharDelay(Integer.parseInt(charDelayField.getText()));
      tempSettings.setLineDelay(Integer.parseInt(lineDelayField.getText()));
      tempSettings.setLineDelay(Integer.parseInt(terminalLinesField.getText()));
      termSettings = tempSettings.clone();
      tempEmuSettings.freqKHz = Integer.parseInt(freqField.getText());
      tempEmuSettings.synchroCycles = Integer.parseInt(syncCyclesField.getText());
      tempEmuSettings.terminalSpeed = Integer.parseInt(termSpeedField.getText());
      tempEmuSettings.linesToShow = Integer.parseInt(emulatorLinesField.getText());
      emuSettings = tempEmuSettings;
      parent.getEmulator().updateSettings(emuSettings);
      parent.getTerminal().updateSettings(termSettings);
      setVisible(false);
      
    }
    catch (Exception x)
    {
      x.printStackTrace();
      showError(KEGUIUtils.getParentFrameOrDialog(this), "Error in values: " + x.getMessage(), "Error");
    }
  }
  
  public TerminalSettings getSettings() { return termSettings; }

  public void actionPerformed(ActionEvent e)
  {
    if (e.getActionCommand().equals("Port"))
      tempSettings.setPortName(((JComboBox)e.getSource()).getSelectedItem().toString());
    else if (e.getActionCommand().equals("Speed"))
      tempSettings.setBaud((Integer)((JComboBox)e.getSource()).getSelectedItem());
    else if (e.getActionCommand().equals("Parity"))
      tempSettings.setParity((Parity)((JComboBox)e.getSource()).getSelectedItem());
    else if (e.getActionCommand().equals("Flow"))
      tempSettings.setFlow((FlowControl)((JComboBox)e.getSource()).getSelectedItem());
    else if (e.getActionCommand().equals("Stop"))
      tempSettings.setStopbits((StopBits)((JComboBox)e.getSource()).getSelectedItem());
    else if (e.getActionCommand().equals("Data"))
      tempSettings.setDatabits((Integer)((JComboBox)e.getSource()).getSelectedItem());
    else if (e.getActionCommand().equals("ROM"))
      tempEmuSettings.writeInRom = ((JCheckBox)e.getSource()).isSelected();
    else if (e.getActionCommand().equals("8KROM"))
      tempEmuSettings.rom8k = ((JCheckBox)e.getSource()).isSelected();
    else if (e.getActionCommand().equals("8KRAM"))
      tempEmuSettings.rom8k = ((JCheckBox)e.getSource()).isSelected();
    else if (e.getActionCommand().equals("65C02"))
      tempEmuSettings.use65C02 = ((JCheckBox)e.getSource()).isSelected();
    else if (e.getActionCommand().equals("EMUDEF"))
    {
      tempEmuSettings = EmulatorSettings.createReplica1Default();
      updateEmulatorValues(tempEmuSettings);
    }
    else if (e.getActionCommand().equals("REPLICA1"))
    {
      tempSettings = TerminalSettings.createReplica1Default();
      updateTerminalValues(tempSettings);
    }
    else if (e.getActionCommand().equals("ACIA"))
    {
      tempSettings = TerminalSettings.createACIADefault();
      updateTerminalValues(tempSettings);
    }
    else if (e.getActionCommand().equals("EOL"))
    {
      // TODO check this (some conversion probably happens behind the scenes as well...)
      String eolStr = ((JComboBox)e.getSource()).getSelectedItem().toString();
      if (eolStr == "CR/LF")
        tempSettings.setLineTerminator(EOL.CRLF);
      else if (eolStr == "LF")
        tempSettings.setLineTerminator(EOL.LF);
      else
        tempSettings.setLineTerminator(EOL.CR);
    }
  }

  public EmulatorSettings getEmulatorSettings()
  {
    return emuSettings;
  }
}
