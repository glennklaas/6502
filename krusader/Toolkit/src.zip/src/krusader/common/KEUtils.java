package krusader.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Arrays;

public class KEUtils
{
  static public String wrap(String str, int width)
  {
    StringBuffer stratName = new StringBuffer(str);
    int i = 0, count = 0;
    while (i < stratName.length() - 1)
    {
      i++;
      count++;
      if (count > width && stratName.charAt(i) == ' ')
      {
        stratName.setCharAt(i, '\n');
        count = 0;
      }
    }

    return stratName.toString();
  }

  public static String repeat(char c, int len)
  {
    if (len < 0)
    {
      throw new IllegalArgumentException("Negative length");
    }

    char[] arr = new char[len];
    Arrays.fill(arr, c);

    return String.valueOf(arr);
  }

  public static String toHex(int i, int minDigits)
  {
    if (i == 0)
      return repeat('0', minDigits);
    
    StringBuilder s = new StringBuilder(Integer.toHexString(i).toUpperCase());

    int check = 0x1 << (4 * (minDigits - 1));
    while (Math.abs(i) < check)
    {
      s.insert(0, "0");
      check /= 16;
    }
    
    return s.toString().substring(s.length() - minDigits);
  }

  public static String toBinary(int i, int minDigits)
  {
    if (i == 0)
      return repeat('0', minDigits);
    
    StringBuilder s = new StringBuilder(Integer.toBinaryString(i));

    int check = 0x1 << (4 * (minDigits - 1));
    while (Math.abs(i) < check)
    {
      s.insert(0, "0");
      check /= 2;
    }
    
    return s.toString().substring(s.length() - minDigits);
  }
    
  public static String getNextNonemptyLine(BufferedReader br)
    throws IOException
  {
    String line = null;
    do
    {
      line = br.readLine();
    } while ((line != null) && (line.trim().length() == 0));

    return line;
  }
}
