package krusader.common;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;

import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;

/**
 * Some utilities for use with GUI's.
 */
public class KEGUIUtils
{
  /**
   * Static inner class for resetting the default cursor on a frame.
   */
  static private class CursorCleaner implements Runnable
  {
    /** Frame we have to reset the cursor for. */
    private RootPaneContainer mFrame = null;

    /** Constructor */
    CursorCleaner(RootPaneContainer frame)
    {
      mFrame = frame;
    }

    /**
     * This method is run in the swing thread to reset the default cursor on the
     * frame supplied at construction.
     */
    public void run()
    {
      mFrame.getGlassPane().setCursor(
          Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
      mFrame.getGlassPane().setVisible(false);
    }
  }

  /**
   * Static method for setting a wait cursor on a window. An event is queued to
   * the swing event queue that will automatically remove the wait cursor when
   * the event queue is exhausted, thus there is no corresponding method for
   * setting the cursor back again.
   * 
   * @param c
   *          Component to set wait cursor on.
   */
  public static void setWaitCursor(Component c)
  {

    // Search for parent dialog, window or frame implementing RootPaneContainer
    // interface.
    while (c != null && (!(c instanceof RootPaneContainer)))
    {
      c = c.getParent();
    }

    // If we can't find one print a warning and return.
    if (c == null)
    {
      System.out.println("Warning: Cannot set wait cursor.");
      return;
    }

    // Cast it.
    RootPaneContainer w = (RootPaneContainer)c;

    // Set wait cursor.
    w.getGlassPane().addMouseListener(new MouseAdapter()
    {
    });
    w.getGlassPane().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    w.getGlassPane().setVisible(true);

    // Add a runnable to the swing event queue to
    // remove the cursor later.
    SwingUtilities.invokeLater(new CursorCleaner(w));
  }

  /**
   * Get parent Frame or Dialog component.
   * 
   * @return a java.awt.Frame or java.awt.Dialog component.
   */
  public static Component getParentFrameOrDialog(Component c)
  {
    while ((c != null) && (!(c instanceof java.awt.Frame))
        && (!(c instanceof java.awt.Dialog)))
    {
      c = c.getParent();
    }
    return c;
  }
  
  public static boolean parentFrameHasFocus(Component c)
  {
    Component parent = getParentFrameOrDialog(c);
    
    if (parent instanceof java.awt.Dialog)
      return false;
    else
    {
      Component focusOwner = ((java.awt.Frame)parent).getFocusOwner();
      if (focusOwner == null)
        return false;
      else
        return true;
    }
  }

  /**
   * Center a dialog on its parent component.
   */
  public static void centerOnParent(Component parent, Dialog dialog)
  {
    Rectangle r = parent.getBounds();
    int x = r.x + (r.width - dialog.getWidth()) / 2;
    int y = r.y + (r.height - dialog.getHeight()) / 2;
    dialog.setLocation(x, (y > 0 ? y : 20));
  }
}
