package krusader.editor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.Element;
import javax.swing.text.JTextComponent;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.Utilities;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
import javax.swing.undo.UndoableEdit;

import krusader.common.KEGUIUtils;
import krusader.common.KEUtils;
import krusader.common.PrefsDialog;
import krusader.editor.formats.BinaryData;
import krusader.editor.source.InvalidLineException;
import krusader.editor.source.SourceDocument;
import krusader.editor.source.SourceLine;
import krusader.emulator.EmulatorPane;
import krusader.emulator.EmulatorSettings;
import krusader.emulator.MemoryDataChooser;
import krusader.emulator.MemoryTransferHelper;
import krusader.terminal.SerialDataDialog;
import krusader.terminal.SerialDataHandler;
import krusader.terminal.TerminalPane;
import krusader.terminal.TerminalSettings;

/*
 * TODO
 *   - undo / redo
 *   - upload/download of data - simple Woz, IntelHex, xmodem
 *   - key commands for copy and paste etc
 *   - move to a new line with arrows => refresh previous (if was edited?)
 *   - interrupt serial transfers
 *   - serial transfer of an arbitrary file
 *   - check upload/download conversions
 */
public class KrusaderEditor extends JFrame implements ChangeListener
{
  private static final String VERSION = "Krusader Toolkit - March 2009 prerelease version 3";

  ToolbarManager toolBar = new ToolbarManager();

  NewFileAction newFileAct = null;
  OpenFileAction openFileAct = null;
  SaveFileAction saveFileAct = null;
  
  SaveMemoryAction saveMemAct = null;
  LoadMemoryAction loadMemAct = null;

  JTabbedPane tabbedPane = null;
  EditorPane editorPane = null;
  String newline = "\n";
  HashMap<Object, Action> actions;

  // undo helpers
  protected UndoAction undoAction;
  protected RedoAction redoAction;
  protected UndoManager undo = new MyUndoManager();

  TransferDataAction transferAct = null;
  RefreshAction refreshAct;
  PrefsAction prefsAct;
  ResetEmulatorAction resetAct;
  ConnectAction connectAct;
  
  PrefsDialog prefsDlg = new PrefsDialog(this, "Preferences");
  SerialDataHandler xferHandler = new SerialDataHandler(this);
  SerialDataDialog xferDlg = new SerialDataDialog(xferHandler, "Transfer Data");
  
  protected boolean isDirty = false;
  protected boolean fileOpen;
  
  private SimpleAttributeSet plainAttributes;
  private SimpleAttributeSet mneAttributes;
  private SimpleAttributeSet commentAttributes;
  private SimpleAttributeSet errorAttributes;
  public SourceFileChooser fileChooser;
  public MemoryDataChooser memoryChooser;
  private TerminalPane terminalPane;
  
  private KrusaderEditorMode activeMode = KrusaderEditorMode.EDITOR;
  EmulatorPane emulatorPane;

  SourceFileHandler sourceFileHandler;
  MemoryTransferHelper memoryTransferHelper;
  Action pasteAction;

  public KrusaderEditor()
  {
    super(VERSION);

    fileChooser = new SourceFileChooser(".", null);
    sourceFileHandler = new SourceFileHandler(this, fileChooser);
    memoryChooser = new MemoryDataChooser(".", null);
    memoryTransferHelper = new MemoryTransferHelper(this, memoryChooser);
    
    JPanel contentPane = (JPanel)this.getContentPane();
    
    JPanel extraPane = new JPanel();

    contentPane.setLayout(new BorderLayout());
    extraPane.setLayout(new BorderLayout());
    
    initAttributes();
    
    editorPane = new EditorPane(this);
    
    extraPane.add(editorPane, BorderLayout.WEST);
    extraPane.add(editorPane.scrollPane, BorderLayout.CENTER);
    
    tabbedPane = new JTabbedPane(JTabbedPane.BOTTOM);
    tabbedPane.add("Editor", extraPane);
    terminalPane = new TerminalPane(this);
    JScrollPane scrollPane = new JScrollPane(terminalPane);
    tabbedPane.add("Terminal", scrollPane);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    
    emulatorPane = new EmulatorPane(this);
    scrollPane = new JScrollPane(emulatorPane);
    tabbedPane.add("Emulator", scrollPane);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    tabbedPane.addChangeListener(this);

    contentPane.add(tabbedPane, BorderLayout.CENTER);
    
    createActionTable(editorPane.getTextPane());
    
    setupFileActions();
    setupEditActions();
    setupActionActions();
    // setupHelpMenu(menuBar, toolBar);

    toolBar.setActiveToolBar(activeMode);
    contentPane.add(toolBar.getActiveToolBar(), BorderLayout.NORTH);
    
    // Create the status area.
    JPanel statusBar = new JPanel(new GridLayout(1, 1));
//    CaretListenerLabel caretListenerLabel = new CaretListenerLabel("Caret Status");
//    editorPane.getTextPane().addCaretListener(caretListenerLabel);
//    statusBar.add(caretListenerLabel);
    
    editorPane.getDocument().setDocumentFilter(new KrusaderSourceFilter(this));

    //contentPane.add(statusBar, BorderLayout.SOUTH);
    
    this.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        doExit();
      }
    });
    
    this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

    int width = getFontMetrics(getFont()).charWidth('8') * 40 + 10;
    int height = getFontMetrics(getFont()).getHeight() * 24 + 82;
    Integer scrollWidth = (Integer) UIManager.get("ScrollBar.width");
    if (scrollWidth == null)
    	scrollWidth = new JScrollBar().getPreferredSize().width;

    Dimension fixedSize = new Dimension(width + scrollWidth, height);
    contentPane.setPreferredSize(fixedSize);
    
    manageActions();
    pack();

    editorPane.getTextPane().requestFocusInWindow();
    
    this.setResizable(false);
  }

  public boolean isEditor() { return getSelectedTabName().equals("Editor"); }
  public boolean isTerminal() { return getSelectedTabName().equals("Terminal"); }
  public boolean isEmulator() { return getSelectedTabName().equals("Emulator"); }

  public String getSelectedTabName() { return tabbedPane.getTitleAt(tabbedPane.getSelectedIndex()); }

  protected JTextComponent getCurrentTextComponent()
  {
    if (isEditor())
      return editorPane.getTextPane();
    else if (isTerminal())
      return terminalPane;
    else // isEmulator()
      return emulatorPane;
  }

  public EmulatorPane getEmulator() { return emulatorPane; }
  public TerminalPane getTerminal() { return terminalPane; }
  public KrusaderSourcePane getEditor() { return editorPane.getTextPane(); }
  
  // This listens for and reports caret movements.
//  protected class CaretListenerLabel extends JLabel implements CaretListener
//  {
//    int lastLineNumber = -1;
//    public CaretListenerLabel(String label)
//    {
//      super(label);
//    }
//
//    // Might not be invoked from the event dispatch thread.
//    public void caretUpdate(CaretEvent e)
//    {
//      displayInfo(getCurrentLineNumber(), getCurrentColumn());
//    }
//
//    // This method can be invoked from any thread. It
//    // invokes the setText and modelToView methods, which
//    // must run on the event dispatch thread. We use
//    // invokeLater to schedule the code for execution
//    // on the event dispatch thread.
//    protected void displayInfo(final int line, final int column)
//    {
//      SwingUtilities.invokeLater(new Runnable()
//      {
//        public void run()
//        {
//          setText("Line " + KEUtils.toHex(line, 3) + ", column " + 
//              KEUtils.toHex(column, 2) + newline);
//        }
//      });
//    }
//  }

  protected class MyUndoManager extends UndoManager
  {
    public synchronized boolean addEdit(UndoableEdit edit)
    {
      UndoableEdit prevEdit = editToBeRedone();
      if (prevEdit != null)
      {
        return !prevEdit.addEdit(edit);
      }
      else
      {
        return super.addEdit(edit);
      }
    }
 }

  // This one listens for edits that can be undone.
  protected class MyUndoableEditListener implements UndoableEditListener
  {
    public void undoableEditHappened(UndoableEditEvent e)
    {
      // Remember the edit and update the menus.
      undo.addEdit(e.getEdit());
      undoAction.updateUndoState();
      redoAction.updateRedoState();
    }
  }

  // And this one listens for any changes to the document.
  protected class MyDocumentListener implements DocumentListener
  {
    public void insertUpdate(DocumentEvent e)
    {
      isDirty = true;
    }

    public void removeUpdate(DocumentEvent e)
    {
      isDirty = true;
    }

    public void changedUpdate(DocumentEvent e)
    {
      isDirty = true;
    }
  }

  protected void setupFileActions()
  {
    JMenu fileMenu = new JMenu("Edit");
    ArrayList<Action> actionsForEditor = new ArrayList<Action>();
    ArrayList<Action> actionsForTerminal = new ArrayList<Action>();
    ArrayList<Action> actionsForEmulator = new ArrayList<Action>(); 

    newFileAct = new NewFileAction(this, "Create a new file", 
        KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
    actionsForEditor.add(newFileAct);

    openFileAct = new OpenFileAction(this, "Open a file", 
        KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
    actionsForEditor.add(openFileAct);

    fileMenu.addSeparator();
    actionsForEditor.add(null); // indicates separator

    saveFileAct = new SaveFileAction(this, "Save this file", null);
    JMenuItem saveItem = fileMenu.add(saveFileAct);
    saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
        InputEvent.CTRL_MASK, false));
    actionsForEditor.add(saveFileAct);
    
    fileMenu.addSeparator();
    actionsForEditor.add(null);
//    actionsForTerminal.add(null);
//    actionsForEmulator.add(null);

    JMenuItem exitItem = new JMenuItem("Quit");
    fileMenu.add(exitItem);
    exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
        InputEvent.CTRL_MASK, false));
    
//    ImageIcon packIcon = new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/pack.gif"));
//    ManagedAction packAction = new ManagedAction(this, "Pack", packIcon , "Make window 40 x 24 size", 
//        KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK, false))
//    {
//      public void actionPerformed(ActionEvent e)
//      {
//        this.parent.pack();
//      }      
//    };
//    actionsForEditor.add(packAction);
//    actionsForTerminal.add(packAction);
//    actionsForEmulator.add(packAction);
//    
//    actionsForEditor.add(null);
//    actionsForTerminal.add(null);
//    actionsForEmulator.add(null);
    
    toolBar.addToToolbar(KrusaderEditorMode.EDITOR, actionsForEditor);
    toolBar.addToToolbar(KrusaderEditorMode.TERMINAL, actionsForTerminal);
    toolBar.addToToolbar(KrusaderEditorMode.EMULATOR, actionsForEmulator);
  }

  protected void setupEditActions()
  {
    JMenu editMenu = new JMenu("Edit");

    ArrayList<Action> actions = new ArrayList<Action>();

    // Undo and redo are actions of our own creation.
    undoAction = new UndoAction();
    editMenu.add(undoAction);

    redoAction = new RedoAction();
    editMenu.add(redoAction);

    editMenu.addSeparator();

    // These actions come from the default editor kit.
    // Get the ones we want and stick them in the menu.
    Action cut = getActionByName(DefaultEditorKit.cutAction);
    cut.putValue(Action.NAME, "Cut");
    cut.putValue(Action.SMALL_ICON, 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/cut.gif")));
    JMenuItem cutItem = editMenu.add(cut);
    cutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
        InputEvent.CTRL_MASK, false));
    actions.add(cut);
    
    Action copy = getActionByName(DefaultEditorKit.copyAction);
    copy.putValue(Action.NAME, "Copy");;
    copy.putValue(Action.SMALL_ICON, 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/copy.gif")));
    JMenuItem copyItem = editMenu.add(copy);
    copyItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,
        InputEvent.CTRL_MASK, false));
    actions.add(copy);

    editorPane.textPane.getInputMap().remove(KeyStroke.getKeyStroke(KeyEvent.VK_V,
        InputEvent.CTRL_MASK, false));
    pasteAction = new PasteAction(this, "Paste", getActionByName(DefaultEditorKit.pasteAction), 
        KeyStroke.getKeyStroke(KeyEvent.VK_W, InputEvent.CTRL_MASK));
    pasteAction.putValue(Action.NAME, "Paste");;
    pasteAction.putValue(Action.SMALL_ICON, 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/paste.gif")));
//    JMenuItem pasteItem = editMenu.add(pasteAction);
//    pasteItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,
//        InputEvent.CTRL_MASK, false));
    actions.add(pasteAction);
    
    editMenu.addSeparator();
    actions.add(null);

    Action select = getActionByName(DefaultEditorKit.selectAllAction);
    select.putValue(Action.NAME, "Select All");
    JMenuItem selectAllItem = editMenu.add(select);
    selectAllItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,
        InputEvent.CTRL_MASK, false));

    toolBar.addToToolbar(KrusaderEditorMode.EDITOR, actions);
    toolBar.addToToolbar(KrusaderEditorMode.TERMINAL, actions);
    toolBar.addToToolbar(KrusaderEditorMode.EMULATOR, actions);
  }

  protected void setupActionActions()
  {
    JMenu actionMenu = new JMenu("Action");

    ArrayList<Action> actionsForEditor = new ArrayList<Action>();
    ArrayList<Action> actionsForTerminal = new ArrayList<Action>();
    ArrayList<Action> actionsForEmulator = new ArrayList<Action>(); 

    transferAct = new TransferDataAction(this, "Send source to KRUSADER", null);
    JMenuItem sendItem = actionMenu.add(transferAct);
    sendItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K,
        InputEvent.CTRL_MASK, false));
    actionsForEditor.add(transferAct);
    actionsForTerminal.add(transferAct);
    actionsForEmulator.add(transferAct);
    
    refreshAct = new RefreshAction(this, "Refresh displayed source", null);
    JMenuItem refreshItem = actionMenu.add(refreshAct);
    refreshItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,
        InputEvent.CTRL_MASK, false));
    actionsForEditor.add(refreshAct);

    connectAct = new ConnectAction(this, "Serial port connect/disconnect", null);
    actionMenu.add(connectAct);
    actionsForEditor.add(connectAct);
    actionsForTerminal.add(connectAct);

    prefsAct = new PrefsAction(this, "Set preferences", null);
    actionMenu.add(prefsAct);
    actionsForEditor.add(prefsAct);
    actionsForTerminal.add(prefsAct);
    actionsForEmulator.add(prefsAct);
    actionsForEditor.add(null);
    actionsForEmulator.add(null);

    loadMemAct = new LoadMemoryAction(this, "Load memory...", null);
   // JMenuItem loadMemItem = actionMenu.add(loadMemAct);
    actionsForEmulator.add(loadMemAct);
    
    saveMemAct = new SaveMemoryAction(this, "Save memory...", null);
   // JMenuItem saveMemItem = actionMenu.add(saveMemAct);
    actionsForEmulator.add(saveMemAct);
    
    actionMenu.addSeparator();
    actionsForEmulator.add(null);
    
    resetAct = new ResetEmulatorAction(this, "Reset the emulated machine - hold down ALT for hard reset", null);
    actionMenu.add(resetAct);
    actionsForEmulator.add(resetAct);

    Icon aboutIcon = new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/about.gif"));
    AbstractAction aboutAction = new AbstractAction("About", aboutIcon)
    {
      public void actionPerformed(ActionEvent e)
      {
        JOptionPane.showMessageDialog(KrusaderEditor.this, 
            "<HTML><H2>The Krusader Toolkit</H2><CENTER>Ken Wessen<BR><BR><I>" + VERSION + "</I></CENTER></HTML>",
            "About KTK", JOptionPane.PLAIN_MESSAGE);
      }
    };
    
    actionsForTerminal.add(null);
    actionsForEmulator.add(null);

    actionsForEditor.add(aboutAction);
    actionsForTerminal.add(aboutAction);
    actionsForEmulator.add(aboutAction);
    
    toolBar.addToToolbar(KrusaderEditorMode.EDITOR, actionsForEditor);
    toolBar.addToToolbar(KrusaderEditorMode.TERMINAL, actionsForTerminal);
    toolBar.addToToolbar(KrusaderEditorMode.EMULATOR, actionsForEmulator);
  }

  public void doExit()
  {
     if (JOptionPane.showConfirmDialog(this, "Are you sure you want to quit?", 
         "Quit the Krusader Toolkit", JOptionPane.YES_NO_OPTION) == 
       JOptionPane.YES_OPTION)
     {
       System.exit(0);
     }
  }

  public void manageActions()
  {
    undoAction.setEnabled(undo.canUndo());
    redoAction.setEnabled(undo.canRedo());

    switch (toolBar.getActiveMode())
    {
      case EDITOR:
        transferAct.setEnabled(true);
        refreshAct.setEnabled(true);
        connectAct.setEnabled(true);
        resetAct.setEnabled(false);
        loadMemAct.setEnabled(false);
        saveMemAct.setEnabled(false);
        break;
      case TERMINAL:
        transferAct.setEnabled(true);
        refreshAct.setEnabled(false);
        connectAct.setEnabled(true);
        resetAct.setEnabled(false);
        loadMemAct.setEnabled(false);
        saveMemAct.setEnabled(false);
        break;
      case EMULATOR:
        transferAct.setEnabled(true);
        refreshAct.setEnabled(false);
        connectAct.setEnabled(false);
        resetAct.setEnabled(true);
        loadMemAct.setEnabled(true);
        saveMemAct.setEnabled(true);
        break;
    }
  }

  public void clearAllText()
  {
    this.getEditorPane().setText("");
  }

  public void setText(String text)
  {
    this.getEditorPane().setText(text);
  }

  public void appendText(String text)
  {
    this.getEditorPane().appendText(text);
  }
  
  public String getSelection()
  {
    return this.getEditorPane().getSelectedText();
  }

  private KrusaderSourcePane getEditorPane()
  {
    return editorPane.getTextPane();
  }

  public static void main(String[] args)
  {
    try
    {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }

    KrusaderEditor ke = new KrusaderEditor();

    // ke.setIconImage(new ImageIcon(
    // krusader.editor.KrusaderEditor.class.getResource("images/basketball.gif")).getImage());

    // Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = ke.getSize();
    if (frameSize.height > screenSize.height)
    {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width)
    {
      frameSize.width = screenSize.width;
    }
    ke.setLocation((screenSize.width - frameSize.width) / 2,
        (screenSize.height - frameSize.height) / 2);
    ke.setVisible(true);
  }

  public SimpleAttributeSet getDefaultAttributes() { return plainAttributes; }
  public SimpleAttributeSet getErrorAttributes() { return errorAttributes; }
  public SimpleAttributeSet getCommentAttributes() { return commentAttributes; }
  public SimpleAttributeSet getMNEAttributes() { return mneAttributes; }
  
  protected void initAttributes()
  {
    /*
     * Setup the basic attributes needed by the editor: - plain text - blue
     * coloured text for mnemonics - red coloured text for directives - italic
     * and grey for comments - lightish green for constants - bold red for
     * errors Later make this configurable
     */

    int size = Math.round(12 * Toolkit.getDefaultToolkit().getScreenResolution() / 72);
    
    plainAttributes = new SimpleAttributeSet();
//    Font[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
//    GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
    //StyleConstants.setFontFamily(plainAttributes, "Monospaced");
    //StyleConstants.setFontFamily(plainAttributes, "Print Char 21");
    StyleConstants.setFontFamily(plainAttributes, "Apple2Forever");
    StyleConstants.setFontSize(plainAttributes, size);
    
    this.setFont(new Font(StyleConstants.getFontFamily(plainAttributes), 
        Font.PLAIN, size));

    mneAttributes = new SimpleAttributeSet(plainAttributes);
    StyleConstants.setForeground(mneAttributes, Color.BLUE);
    
    commentAttributes = new SimpleAttributeSet(plainAttributes);
    StyleConstants.setForeground(commentAttributes, Color.GRAY);
    StyleConstants.setItalic(commentAttributes, true);

    errorAttributes = new SimpleAttributeSet(plainAttributes);
    StyleConstants.setForeground(errorAttributes, Color.RED);
    StyleConstants.setItalic(errorAttributes, true);
  }

  // The following two methods allow us to find an
  // action provided by the editor kit by its name.
  private void createActionTable(JTextComponent textComponent)
  {
    actions = new HashMap<Object, Action>();
    Action[] actionsArray = textComponent.getActions();
    for (int i = 0; i < actionsArray.length; i++)
    {
      Action a = actionsArray[i];
      actions.put(a.getValue(Action.NAME), a);
    }
  }

  private Action getActionByName(String name)
  {
    return actions.get(name);
  }

  class UndoAction extends AbstractAction
  {
    public UndoAction()
    {
      super("Undo");
      setEnabled(false);
    }

    public void actionPerformed(ActionEvent e)
    {
      try
      {
        undo.undo();
      }
      catch (CannotUndoException ex)
      {
        System.out.println("Unable to undo: " + ex);
        ex.printStackTrace();
      }
      updateUndoState();
      redoAction.updateRedoState();
    }

    protected void updateUndoState()
    {
      if (undo.canUndo())
      {
        setEnabled(true);
        putValue(Action.NAME, undo.getUndoPresentationName());
      }
      else
      {
        setEnabled(false);
        putValue(Action.NAME, "Undo");
      }
    }
  }

  class RedoAction extends AbstractAction
  {
    public RedoAction()
    {
      super("Redo");
      setEnabled(false);
    }

    public void actionPerformed(ActionEvent e)
    {
      try
      {
        undo.redo();
      }
      catch (CannotRedoException ex)
      {
        System.out.println("Unable to redo: " + ex);
        ex.printStackTrace();
      }
      updateRedoState();
      undoAction.updateUndoState();
    }

    protected void updateRedoState()
    {
      if (undo.canRedo())
      {
        setEnabled(true);
        putValue(Action.NAME, undo.getRedoPresentationName());
      }
      else
      {
        setEnabled(false);
        putValue(Action.NAME, "Redo");
      }
    }
  }
  
  public SourceDocument createSourceDocument()
  {
    SourceDocument source = new SourceDocument();
    
    Element parent = editorPane.getDocument().getDefaultRootElement();
    for (int i = 0; i < parent.getElementCount(); ++i)
    {
      try
      {
        source.addLine(new SourceLine(getLineText(i)));
      }
      catch (InvalidLineException e)
      {
        JOptionPane.showMessageDialog(this, "Error on line " + KEUtils.toHex(i + 1, 3),
            "Source Format Error", JOptionPane.ERROR_MESSAGE);
        selectLine(i);
        return null;
      }
    }
    
    return source;
  }
  
  public String getLineText(int lineIndex)
  {
    Element parent = editorPane.getDocument().getDefaultRootElement();
    Element lineElem = parent.getElement(lineIndex);
    int lineStart = lineElem.getStartOffset();
    int lineEnd = lineElem.getEndOffset();
    try
    {
      return editorPane.getDocument().getText(lineStart, lineEnd - lineStart);
    }
    catch (Exception e)
    {
      e.printStackTrace();
      return "";
    }
  }
  
  public String getCurrentLineText()
  {
    int selStart = getCurrentSelection();
    Element parent = editorPane.getDocument().getDefaultRootElement();
    return getLineText(parent.getElementIndex(selStart));
  }
  
  public Element getLineElement(int i)
  {
    Element parent = editorPane.getDocument().getDefaultRootElement();
    return parent.getElement(i);
  }
  
  public int getLineStart(int i)
  {
    return getLineElement(i).getStartOffset();
  }
  
  public int getLineStart()
  {
    int selStart = getCurrentSelection();
    Element parent = editorPane.getDocument().getDefaultRootElement();
    return getLineStart(parent.getElementIndex(selStart));
  }
  
  public int getLineEnd(int i)
  {
    return getLineElement(i).getEndOffset();
  }
  
  public int getLineEnd()
  {
    int selStart = getCurrentSelection();
    Element parent = editorPane.getDocument().getDefaultRootElement();
    return getLineEnd(parent.getElementIndex(selStart));
  }
  
  public int getLineLength()
  {
    Element lineElem = getLineElement(getCurrentLineNumber() - 1);
    return lineElem.getEndOffset() - lineElem.getStartOffset();
  }

  public int getCurrentLineNumber()
  {
    int selStart = getCurrentSelection();
    Element parent = editorPane.getDocument().getDefaultRootElement();
    return 1 + parent.getElementIndex(selStart);
  }
  
  public int getCurrentSelection()
  {
    return editorPane.getTextPane().getSelectionStart();
  }

  public void selectLine(int line)
  {
    int start = getLineStart(line);
    int end = getLineEnd(line);
    editorPane.getTextPane().setSelectionStart(start);
    editorPane.getTextPane().setSelectionEnd(end);
  }
  
  public void showLine(int line)
  {
    int start = getLineStart(line);
    editorPane.getTextPane().setSelectionStart(start);
    editorPane.getTextPane().setSelectionEnd(start);
  }
  
  synchronized public int getCurrentColumn()
  {
    try
    {
      int selStart = editorPane.getTextPane().getSelectionStart();
      return selStart - Utilities.getRowStart(editorPane.getTextPane(), selStart) + 1;
    }
    catch (Exception e)
    {
      return 0;
    }
  }

  public void colorise(boolean success)
  {
    ((StyledDocument)editorPane.getDocument()).setCharacterAttributes(getLineStart(), 
        getLineLength(), success ? plainAttributes : errorAttributes, true);
    ((StyledDocument)editorPane.getDocument()).setCharacterAttributes(getLineEnd(), 
        0, plainAttributes, true);
  }

  public void setPlain()
  {
    ((StyledDocument)editorPane.getDocument()).setCharacterAttributes(getCurrentSelection(), 
        0, plainAttributes, true);
  }

  protected void handlePrefs()
  {
    KEGUIUtils.centerOnParent(this, prefsDlg);
    prefsDlg.setVisible(true);
    emulatorPane.updateSettings(getEmulatorSettings());
  }

  public TerminalSettings getTerminalSettings() 
  {
    return prefsDlg.getSettings();
  }

  public EmulatorSettings getEmulatorSettings() 
  {
    return prefsDlg.getEmulatorSettings();
  }

  public void reconnect()
  {
    try
    {
      connect(); 
    }
    catch (Exception x)
    {
      x.printStackTrace();
      JOptionPane.showMessageDialog(this, x.getMessage(), 
          "Connection Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  public boolean isConnected()
  {
    return terminalPane.isConnected();
  }

  public void disconnect()
  {
    terminalPane.disconnect();     
  }

  public void connect() throws Exception
  {
    terminalPane.connect(getTerminalSettings().getPort());
  }

  public void sendData(String data)
  {
    terminalPane.sendData(data);
  }

  public void stateChanged(ChangeEvent e)
  {
    switch (tabbedPane.getSelectedIndex())
    {
      case 0:
        activeMode = KrusaderEditorMode.EDITOR;
        break;
      case 1:
        activeMode = KrusaderEditorMode.TERMINAL;
        break;
      case 2:
        activeMode = KrusaderEditorMode.EMULATOR;
        break;
    }

    getContentPane().remove(toolBar.getActiveToolBar());
    toolBar.setActiveToolBar(activeMode);
    getContentPane().add(toolBar.getActiveToolBar(), BorderLayout.NORTH);
    manageActions();
    toolBar.getActiveToolBar().repaint();
  }

  public void sendToEmulator(BinaryData data)
  {
    emulatorPane.receiveData(data);
  }

  public Action getPasteAction()
  {
    return pasteAction;
  }

  public void setSourceDocument(SourceDocument newSource)
  {
    if (newSource != null)
    {
      setText("");
      StringBuilder sb = new StringBuilder();
      int count = 0;
      for (SourceLine line : newSource.getLines())
      {
        sb.append(line.getLineText() + "\n");
        if (count++ == 50)
        {
          appendText(sb.toString());
          count = 0;
          sb = new StringBuilder();
        }
      }
      appendText(sb.toString());
      selectLine(0); 
    }
  }

  public boolean doSave()
  {
    try
    {
      if (sourceFileHandler.saveSource(createSourceDocument()))
      {
        isDirty = false;
        return true;
      }
      else
      {
        return false;
      }
    }
    catch (IOException e1)
    {
      e1.printStackTrace();
      return false;
    }
  }

  public void setDirty()
  {
    isDirty = true;
  }
}

abstract class ManagedAction extends AbstractAction
{
  KrusaderEditor parent = null;
  String tooltip = null;
  
//  String command = "<whatever>";
//  int condition; //one of WHEN_IN_FOCUSED_WINDOW, WHEN_FOCUSED,
//  WHEN_ANCESTOR_OF_FOCUSED_COMPONENT
//  component.getInputMap(condition).put(ks, command);
//  component.getActionMap().put(commmand, a);

  ManagedAction(KrusaderEditor p, String text, ImageIcon icon, String tooltip, KeyStroke accelerator)
  {
    super(text, icon);
    parent = p;
    this.tooltip = tooltip;
    if (tooltip != null)
      this.putValue(Action.SHORT_DESCRIPTION, tooltip);
    if (accelerator != null)
      this.putValue(Action.ACCELERATOR_KEY, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    parent.manageActions();
  }

  public boolean hasTooltip() { return tooltip != null && tooltip.trim().length() > 0; }
  public String getTooltip() { return tooltip; }
};

class NewFileAction extends ManagedAction
{
  NewFileAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "New...", 
      new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/new.gif")), 
      tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    if (parent.isDirty && JOptionPane.showConfirmDialog(parent, "Save current file?", 
        "New File", JOptionPane.YES_NO_OPTION) == 
      JOptionPane.YES_OPTION)
    {
      if (!parent.doSave())
        return;
    }
    parent.editorPane.getTextPane().setText("");
    super.actionPerformed(e);
  }
};

class OpenFileAction extends ManagedAction
{
  OpenFileAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Open...", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/open.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    if (parent.isDirty && JOptionPane.showConfirmDialog(parent, "Save current file?", 
        "New File", JOptionPane.YES_NO_OPTION) == 
      JOptionPane.YES_OPTION)
    {
      if (!parent.doSave())
        return;
    }
    try
    {
      SourceDocument newSource = parent.sourceFileHandler.loadSource();
      parent.setSourceDocument(newSource);
    }
    catch (IOException e1)
    {
      e1.printStackTrace();
    }
    super.actionPerformed(e);
  }
};

class SaveFileAction extends ManagedAction
{
  SaveFileAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Save...", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/save.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    try
    {
      parent.sourceFileHandler.saveSource(parent.createSourceDocument());
    }
    catch (IOException e1)
    {
      e1.printStackTrace();
    }
    
    super.actionPerformed(e);
  }
};

class TransferDataAction extends ManagedAction
{
  TransferDataAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Transfer...", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/transfer.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    parent.xferHandler.transfer(parent, parent.xferDlg);
    super.actionPerformed(e);
  }
};

class RefreshAction extends ManagedAction
{
  RefreshAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Refresh", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/refresh.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    KEGUIUtils.setWaitCursor(parent);
    int savedline = parent.getCurrentLineNumber() - 1;
    Element root = parent.editorPane.getDocument().getDefaultRootElement();
    for (int i = 0; i < root.getElementCount(); ++i)
    {
      try
      {
        parent.selectLine(i);
        new SourceLine(parent.getLineText(i)).validate();   
        parent.colorise(true);
      }
      catch (InvalidLineException ilx)
      {
        parent.colorise(false);
      }
    }
    parent.showLine(savedline);
    super.actionPerformed(e);
  }
};

class PrefsAction extends ManagedAction
{
  PrefsAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Prefs", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/prefs.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    parent.handlePrefs();
    super.actionPerformed(e);
  }
};

class ConnectAction extends ManagedAction
{
  ConnectAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Connect", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/connect.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    if (parent.isConnected())
    {
      parent.disconnect();
      Object source = e.getSource();
      if (source instanceof JMenuItem)
        ((JMenuItem)source).setText("Connect");
      else
        ((JButton)source).setIcon(new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/connect.gif")));
      ((JButton)e.getSource()).setIcon(new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/connect.gif")));
    }
    else
    {
      try
      {
        parent.connect();
        Object source = e.getSource();
        if (source instanceof JMenuItem)
          ((JMenuItem)source).setText("Disconnect");
        else
          ((JButton)source).setIcon(new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/disconnect.gif")));
      }
      catch (Exception x)
      {
        x.printStackTrace();
        JOptionPane.showMessageDialog(parent, x.getMessage(), 
            "Connection Error", JOptionPane.ERROR_MESSAGE);
      }
    }
    super.actionPerformed(e);
  }
};

class ResetEmulatorAction extends ManagedAction
{
  ResetEmulatorAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Reset", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/reset.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    if ((e.getModifiers() & ActionEvent.ALT_MASK) > 0)
      parent.emulatorPane.hardReset();
    else
      parent.emulatorPane.softReset();
  }
};

class SaveMemoryAction extends ManagedAction
{
  SaveMemoryAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Save memory...", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/savemem.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    try
    {
      parent.memoryTransferHelper.saveMemory(parent.emulatorPane);
    }
    catch (IOException e1)
    {
      e1.printStackTrace();
    }
    
    super.actionPerformed(e);
  }
};

class LoadMemoryAction extends ManagedAction
{
  LoadMemoryAction(KrusaderEditor p, String tooltip, KeyStroke accelerator)
  {
    super(p, "Load memory...", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/loadmem.gif")), 
        tooltip, accelerator);
  }

  public void actionPerformed(ActionEvent e)
  {
    try
    {
      BinaryData data = parent.memoryTransferHelper.loadMemory();
      if (data != null)
        parent.emulatorPane.receiveData(data);
    }
    catch (IOException e1)
    {
      e1.printStackTrace();
    }
    
    super.actionPerformed(e);
  }
};

class PasteAction extends ManagedAction
{
  private Action truePasteAction;

  PasteAction(KrusaderEditor p, String tooltip, Action action, KeyStroke accelerator)
  {
    super(p, "Paste...", 
        new ImageIcon(KrusaderEditor.class.getResource("/krusader/resources/paste.gif")), 
        tooltip, accelerator);
    truePasteAction = action;
  }

  public void actionPerformed(ActionEvent e)
  {
    if (parent.isEmulator())
    {
      parent.emulatorPane.typeFromClipboard();
    }
    else if (parent.isEditor())
    {
      truePasteAction.actionPerformed(e);  
      parent.refreshAct.actionPerformed(e);
    }
    else
    {
      truePasteAction.actionPerformed(e);    
    }
    
    super.actionPerformed(e);
  }
};

