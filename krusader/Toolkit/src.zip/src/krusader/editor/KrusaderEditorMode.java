package krusader.editor;

public enum KrusaderEditorMode
{
  EDITOR, TERMINAL, EMULATOR
}
