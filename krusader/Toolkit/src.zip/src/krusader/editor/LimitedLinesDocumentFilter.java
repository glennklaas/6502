package krusader.editor;

import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.Element;

public class LimitedLinesDocumentFilter extends DocumentFilter
{
  int maxLines;

  // limit is the maximum number of characters allowed.
  public LimitedLinesDocumentFilter(int limit)
  {
    maxLines = limit;
  }
  
  public void setMaxLines(AbstractDocument doc, int newMaxLines)
  {
    if (maxLines > newMaxLines)
    {
      int lines = 0;
      try
      {
        do
        {
          deleteTopLine(doc);
          lines = doc.getDefaultRootElement().getElementCount();
        } while (lines > newMaxLines);
      }
      catch (BadLocationException e)
      {
        e.printStackTrace();
      } 
    }
    this.maxLines = newMaxLines;
  }

  // This method is called when characters are inserted into the document
  public void insertString(DocumentFilter.FilterBypass fb, int offset, String str, AttributeSet attr) 
    throws BadLocationException
  {
    replace(fb, offset, 0, str, attr);
  }

  // This method is called when characters in the document are replace with
  // other characters
  public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String str, AttributeSet attrs) 
    throws BadLocationException
  {
    fb.replace(offset, length, str, attrs);
    int lines = fb.getDocument().getDefaultRootElement().getElementCount();
    if (lines > maxLines)
    {
      deleteTopLine((AbstractDocument)fb.getDocument());
    }
  }
  
  private void deleteTopLine(AbstractDocument doc) throws BadLocationException
  {
    Element topLine = doc.getDefaultRootElement().getElement(0);
    doc.remove(0, topLine.getEndOffset());
  }
}
