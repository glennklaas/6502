package krusader.editor;

import java.util.ArrayList;

import javax.swing.Action;
import javax.swing.JToolBar;

public class ToolbarManager
{
  private JToolBar editorToolBar = new JToolBar();
  private JToolBar terminalToolBar = new JToolBar();
  private JToolBar emulatorToolBar = new JToolBar();
  private KrusaderEditorMode activeMode;
  
  public ToolbarManager()
  {
  }
  
  public void addToToolbar(KrusaderEditorMode mode, ArrayList<Action> actions)
  {
    JToolBar tempToolBar = getToolBar(mode);
    
    for (Action action : actions)
    {
      if (action == null)
        tempToolBar.addSeparator();
      else
      {
        tempToolBar.add(action);
        if (action instanceof ManagedAction && ((ManagedAction)action).hasTooltip())
          tempToolBar.setToolTipText(((ManagedAction)action).getTooltip());
      }
    }
  }
  
  public KrusaderEditorMode getActiveMode()
  {
    return activeMode;
  }
  
  public JToolBar getActiveToolBar()
  {
    return getToolBar(activeMode);
  }
  
  public JToolBar getToolBar(KrusaderEditorMode mode)
  {
    emulatorToolBar.setRequestFocusEnabled(false); 
      
    switch (mode)
    {
      case EDITOR:
        return editorToolBar;
      case EMULATOR:
        return emulatorToolBar;
      case TERMINAL:
        return terminalToolBar;
    }
    throw new RuntimeException("Unknown mode: " + activeMode);
  }
  
  public void setActiveToolBar(KrusaderEditorMode mode)
  {
    activeMode = mode;
  }
}
