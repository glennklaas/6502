package krusader.editor;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

import krusader.common.KEUtils;
import krusader.editor.source.SourceLine;

public class KrusaderSourceFilter extends DocumentFilter 
{  
  private KrusaderEditor parent;
  private boolean newLine;
  
  public KrusaderSourceFilter(KrusaderEditor editor)
  {
    parent = editor;
  }
  
  public void insertString(DocumentFilter.FilterBypass fb, int offset,
      String text, AttributeSet attr) throws BadLocationException 
  {
    parent.setDirty();
    newLine = text.equals("\n");
    String [] lines;
    if (newLine)
      lines = new String[] { parent.getCurrentLineText() + "\n" };
    else
      lines = text.split("\\n");
    if (lines.length == 0)
      lines = new String [] { "\n" };
    boolean multiline = lines.length > 1;
    for (String line : lines)
    {
      String t = checkText(line + (multiline ? "\n" : ""));
      
      int end  = parent.getLineEnd();
      
      if (newLine || (t.length() > 0 && t.charAt(t.length() - 1) == '\n'))
      {
        SourceLine sourceLine = null;
        String sourceText;
        try
        {
          sourceLine = new SourceLine(t);
          sourceText = sourceLine.getLineText() + "\n";
          fb.insertString(parent.getLineStart(), sourceText, attr);
          parent.colorise(true);      
        }
        //catch (InvalidLineException e)
        catch (Exception e)
        {
          if (newLine)
          {
            sourceText = "\n";
            parent.colorise(false);
            fb.insertString(parent.getCurrentSelection(), sourceText, parent.getErrorAttributes());
          }
          else
          {
            sourceText = t;// + "\n";
            fb.insertString(parent.getCurrentSelection(), sourceText, parent.getErrorAttributes());
          }
          parent.setPlain();
          e.printStackTrace();
        }
        offset += sourceText.length();  
      }      
      else if (offset + t.length() < end)
      {
        fb.insertString(offset, t, parent.getDefaultAttributes());
        offset += t.length();        
      }
      else
      {
        fb.insertString(offset, t, parent.getDefaultAttributes());
        offset += t.length();        
      }
    }
  }

  public void replace(DocumentFilter.FilterBypass fb, int offset, int length,
      String text, AttributeSet attr) throws BadLocationException 
  {
    parent.setDirty();
    newLine = text.equals("\n");
    String [] lines;
    if (newLine)
      lines = parent.getCurrentLineText().split("\n");
    else
      lines = text.split("\\r\\n|\\r|\\n");
    if (lines.length == 0)
      lines = new String [] { "\n" };
    boolean multiline = lines.length > 1;
    for (String line : lines)
    {
      String t = checkText(line + (multiline ? "\n" : ""));
      
      int end  = parent.getLineEnd();
      
      if (newLine || (t.length() > 0 && t.charAt(t.length() - 1) == '\n'))
      {
        SourceLine sourceLine = null; 
        String sourceText;
        try
        {
          sourceLine = new SourceLine(t);
          sourceText = sourceLine.getLineText() + "\n";
          fb.replace(parent.getLineStart(), parent.getLineLength() - 1/*length*/, sourceText, attr);
          parent.colorise(true);      
        }
        //catch (InvalidLineException e)
        catch (Exception e)
        {
          if (newLine)
          {
            sourceText = "\n";
            parent.colorise(false);
            fb.replace(parent.getCurrentSelection(), 0, sourceText, parent.getErrorAttributes());
          }
          else
          {
            sourceText = t;// + "\n";
            fb.replace(parent.getCurrentSelection(), 0, sourceText, parent.getErrorAttributes());
          }
          parent.setPlain();
          //e.printStackTrace();
          System.err.println(e.getMessage());
        }
        offset += sourceText.length();  
      }      
      else if (offset + t.length() < end)
      {
        fb.replace(offset, t.length(), t, parent.getDefaultAttributes());
        offset += t.length();        
      }
      else
      {
        fb.replace(offset, length, t, parent.getDefaultAttributes());
        offset += t.length();        
      }
    }
  }

  public void remove(FilterBypass fb, int offset, int length) throws BadLocationException
  {
    parent.setDirty();
    if (length > 1)
    {
      super.remove(fb, offset, length); 
    }
    else
    {
      String rawText = parent.getCurrentLineText();
      boolean commentOnly = rawText.length() > 0 && rawText.charAt(0) == ';';
      int column = parent.getCurrentColumn();
      int newColumn = handleBackSpace(column, commentOnly);
      int extra = newColumn == column ? 0 : column - rawText.indexOf(' ', newColumn) - 2;
  
      super.remove(fb, offset - extra, length + extra);
    }
    
    // TODO maintain source program as well...
  }
  
  // reproduce the KRUSADER editor behaviour
  protected String checkText(String text)
  {
    int column = parent.getCurrentColumn();

    String rawText = parent.getCurrentLineText();
    boolean commentOnly = rawText.length() > 0 && rawText.charAt(0) == ';';
    
    text = text.toUpperCase().replaceAll("[^A-Z0-9 $;.(),*!?#=<>'/\\t\\n+-]", "");

    boolean isSpace = text.equals(" ") || text.equals("\t");
    
    if (!newLine && !commentOnly)
    {
      if (column == SourceLine.LABEL_END + 1)
        return isSpace ? " " : "";
      else if (column == SourceLine.MNE_END + 1)
        return isSpace ? " " : "";
      else if (column == SourceLine.ARGS_END + 1)
        return isSpace ? " " : "";
    }
    
    if (column >= SourceLine.COMMENT_END)
    {
      return newLine ? text + "\n" : "";
    }
    else if (isSpace)
    {
      return KEUtils.repeat(' ', getSpacesToNextColumn(column, commentOnly) + 1);
    }
    else
    {
      return text.toUpperCase();
    }
  }
  
  private int getSpacesToNextColumn(int column, boolean commentOnly)
  {     
    // behaviour of space depends on the column we are in
    if (column <= SourceLine.LABEL_END + 1)
      column = SourceLine.LABEL_END + 1;
    else if (!commentOnly && column <= SourceLine.MNE_END + 1)
      column = SourceLine.MNE_END + 1;
    else if (!commentOnly && column <= SourceLine.ARGS_END + 1)
      column = SourceLine.ARGS_END + 1;

    return column - parent.getCurrentColumn();
  }
  
  protected int handleBackSpace(int column, boolean commentOnly)
  {     
    if (commentOnly)
      return column;
    else if (column == SourceLine.MNE_START)
      column = SourceLine.LABEL_START - 1;
    else if (column == SourceLine.ARGS_START)
      column = SourceLine.MNE_START - 1;
    else if (column == SourceLine.COMMENT_START)
      column = SourceLine.ARGS_START - 1;

    return column;
  }
}