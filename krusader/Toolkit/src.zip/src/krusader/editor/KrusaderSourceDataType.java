package krusader.editor;

public enum KrusaderSourceDataType
{
  BINARY, INTEL_HEX, HEX, TEXT;
  
  static String [] extensions = { "bin", "ihex", "hex", "txt", "asm" };
  
  static String [] getAllowedExtensions()
  {
    return extensions;
  }
  
  static public boolean isAllowedExtension(String extension)
  {
    try
    {
      return fromExtension(extension) != null;
    }
    catch (IllegalArgumentException iax)
    {
      return false;
    }
  }
  
  static public KrusaderSourceDataType fromExtension(String extension)
  {
    if (extension.equals("bin"))
      return BINARY;
    else if (extension.equals("ihex"))
      return INTEL_HEX;
    else if (extension.equals("hex"))
      return HEX;
    else if (extension.equals("txt"))
      return TEXT;
    else if (extension.equals("asm"))
      return TEXT;
    else
      return null;
  }
  
  public String toExtension()
  {
    switch (this)
    {
      case BINARY:
        return "bin";
      case INTEL_HEX:
        return "ihex";
      case HEX:
        return "hex";
      case TEXT:
        return "asm";
      default:
        return "???";
    }
  }
}
