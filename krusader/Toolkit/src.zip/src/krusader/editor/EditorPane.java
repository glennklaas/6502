package krusader.editor;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;

import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.text.AbstractDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

import krusader.common.KEUtils;
import krusader.common.swing.find.TextComponentFindAction;

public class EditorPane extends JPanel
{
  KrusaderSourcePane textPane;
  AbstractDocument doc;
  JScrollPane scrollPane;
  
  public EditorPane(KrusaderEditor parent)
  {    
    textPane = new KrusaderSourcePane(this);
    textPane.setFont(parent.getFont());
    textPane.setForeground(Color.GREEN);
    textPane.setBackground(Color.BLACK);
    textPane.setCaretColor(Color.GREEN);
    
    //new TextComponentFindAction(true).install(textPane);

    TextComponentFindAction findAction = new TextComponentFindAction(true);
    
    ActionMap actionMap = textPane.getActionMap();
    InputMap inputMap = textPane.getInputMap();
    String name = (String)findAction.getValue(Action.NAME);
    actionMap.put(name, findAction);
    inputMap.put((KeyStroke)findAction.getValue(Action.ACCELERATOR_KEY), name);
    
    this.setFont(parent.getFont());
    this.setForeground(Color.GREEN);
    this.setBackground(Color.BLACK);
    
    int width = getFontMetrics(getFont()).charWidth('8') * 3 + 2;
    setMinimumSize(new Dimension(width, 30));
    setPreferredSize(new Dimension(width, 30));
    setMaximumSize(new Dimension(width, 30));
    
    textPane.setCaretPosition(0);
    textPane.setMargin(new Insets(5, 5, 5, 5));
    
    //StyledDocument styledDoc = editorPane.getStyledDocument();
    Document styledDoc = textPane.getDocument();
    doc = (AbstractDocument)styledDoc;

    // Start watching for undoable edits and caret changes.
    doc.addUndoableEditListener(new UndoableEditListener());
    doc.addDocumentListener(new SourceDocumentListener());
        
    addBindings();

    scrollPane = new JScrollPane(textPane);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
  }

  public void paint(Graphics g)
  {
    super.paint(g);

    // We need to properly convert the points to match the viewport
    // Read docs for viewport
    int start = textPane.viewToModel(scrollPane.getViewport().getViewPosition()); // starting
                                                                              // pos
                                                                              // in
                                                                              // document
    int end = textPane.viewToModel(new Point(scrollPane.getViewport()
        .getViewPosition().x
        + textPane.getWidth(), scrollPane.getViewport().getViewPosition().y
        + textPane.getHeight()));
    // end pos in doc

    // translate offsets to lines
    Document doc = textPane.getDocument();
    int startline = doc.getDefaultRootElement().getElementIndex(start);// + 1;
    int endline = doc.getDefaultRootElement().getElementIndex(end);// + 1;

    int fontHeight = g.getFontMetrics(textPane.getFont()).getHeight();
    int fontDesc = g.getFontMetrics(textPane.getFont()).getDescent();
    int starting_y = -1;

    try
    {
      starting_y = textPane.modelToView(start).y
          - scrollPane.getViewport().getViewPosition().y + fontHeight
          - fontDesc;
    }
    catch (BadLocationException e1)
    {
      e1.printStackTrace();
    }

    for (int line = startline, y = starting_y; line <= endline; y += fontHeight, line++)
    {
      g.drawString(KEUtils.toHex(line, 3), 0, y + 1);
    }
  } 

  KrusaderSourcePane getTextPane() { return textPane; }
  AbstractDocument getDocument() { return doc; }

  // Add a couple of emacs key bindings for navigation.
  protected void addBindings()
  {
//    InputMap inputMap = editorPane.getInputMap();

    // Space is special for Krusader input
//    KeyStroke key = KeyStroke.getKeyStroke((char)KeyEvent.VK_SPACE);
//    inputMap.put(key, new SpaceHandlingAction(this));
  }
}
