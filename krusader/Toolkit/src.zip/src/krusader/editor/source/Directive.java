package krusader.editor.source;

public enum Directive
{
  B, W, S, EQ, M;

  static final private char [] tokenValues = {'B', 'W', 'S', '=', 'M'};

  public Byte tokenValue()
  {
    return Byte.parseByte("" + (tokenValues[this.ordinal()] + 1));
  }
  
  public String stringValue()
  {
    return "" + tokenValues[this.ordinal()];
  }

  public static Directive fromToken(Byte token)
  {
    int index = token - 1;
    if (index == '=')
      return EQ;
    else
      return valueOf("" + (char)index);
  }

  public static Directive guess(String str)
  {
    // some common variants
    if (str.equalsIgnoreCase(".="))
      return EQ;
    else if (str.equalsIgnoreCase(".EQU"))
      return EQ;
    else if (str.equalsIgnoreCase(".EQU"))
      return EQ;
    else if (str.equalsIgnoreCase(".DC"))
      return EQ;
    else if (str.equalsIgnoreCase(".B"))
      return B;
    else if (str.equalsIgnoreCase(".BYTE"))
      return B;
    else if (str.equalsIgnoreCase(".DB"))
      return B;
    else if (str.equalsIgnoreCase(".W"))
      return W;
    else if (str.equalsIgnoreCase(".WORD"))
      return W;
    else if (str.equalsIgnoreCase(".DW"))
      return W;
    else if (str.equalsIgnoreCase(".S"))
      return S;
    else if (str.equalsIgnoreCase(".ASCII"))
      return S;
    else if (str.equalsIgnoreCase(".STR"))
      return S;
    else if (str.equalsIgnoreCase(".DS"))
      return S;
    else if (str.equalsIgnoreCase(".M"))
      return M;
    else if (str.equalsIgnoreCase(".*"))
      return M;
    else if (str.equalsIgnoreCase(".ORG"))
      return M;
    else if (str.equalsIgnoreCase(".START"))
      return M;
    else
      return null;
  }

  public static Directive fromChar(char character)
  {
    for (int i = 0; i < tokenValues.length; ++i)
    {
      if (tokenValues[i] == character)
        return values()[i];
    }
    return null;
  }
}
