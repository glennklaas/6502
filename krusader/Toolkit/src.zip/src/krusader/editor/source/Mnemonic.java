package krusader.editor.source;

public enum Mnemonic
{
  PHP, CLC, PLP, SEC, PHA, CLI, PLA, SEI, DEY, TYA, 
  TAY, CLV, INY, CLD, INX, SED, TXA, TXS, TAX, TSX, 
  DEX, NOP, BRK, RTI, RTS, BPL, BMI, BVC, BVS, BCC, 
  BCS, BNE, BEQ, JSR, BIT, JMP, STY, LDY, CPY, CPX, 
  ORA, AND, EOR, ADC, STA, LDA, CMP, SBC, ASL, ROL, 
  LSR, ROR, STX, LDX, DEC, INC;
  
  static int numMnemonics = 56;

  public Byte tokenValue()
  {
    return Byte.parseByte("" + (this.ordinal() + 1));
  }

  public static Mnemonic fromToken(Byte token)
  {
    return values()[token - 1];
  }
}