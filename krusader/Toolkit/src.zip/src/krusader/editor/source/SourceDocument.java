package krusader.editor.source;

import java.util.ArrayList;

public class SourceDocument
{
  ArrayList<SourceLine> lines = new ArrayList<SourceLine>();
  
  public SourceDocument()
  {
  }
  
  public SourceDocument(ArrayList<Byte> bytes) throws InvalidLineException
  {
    ArrayList<Byte> tokenizedData = new ArrayList<Byte>();
    for (Byte oneByte : bytes)
    {
      tokenizedData.add(oneByte);
      if (oneByte.equals(SourceLine.EOL))
      {
        if (tokenizedData.size() == 1)
          break;  // end of program
        lines.add(new SourceLine(tokenizedData));
        tokenizedData.clear();
      }
    }
  }
  
  public ArrayList<Byte> getTokenized() throws InvalidLineException
  {
    ArrayList<Byte> bytes = new ArrayList<Byte>();
    for (SourceLine line : lines)
    {
      try
      {
        bytes.addAll(line.tokenise());
      }
      catch (InvalidLineException e)
      {
        e.printStackTrace();
        throw new InvalidLineException("Error: " + line.toString());
      }
    }
    
    bytes.add(SourceLine.EOL);  // consecutive EOLs => EOD
    
    return bytes;
  }
  
  public void insertLine(int insertAt, SourceLine newLine)
  {
    lines.add(insertAt, newLine);
  }
  
  public void insertLines(int insertAt, ArrayList<SourceLine> newLines)
  {
    lines.addAll(insertAt, newLines);
  }
  
  public void deleteLine(int lineNumber)
  {
    lines.remove(lineNumber);
  }
  
  public void deleteLines(int firstLine, int lastLine)
  {
    int i = lastLine;
    while (i >= firstLine)
    {
      lines.remove(i--);
    }
  }
  
  public void replaceLine(int lineNumber, SourceLine newLine)
  {
    lines.set(lineNumber, newLine);
  }

  public SourceLine getLine(int i)
  {
    return lines.get(i);
  }

  public ArrayList<SourceLine> getLines()
  {
    return lines;
  }

  public void addLine(SourceLine line)
  {
    lines.add(line);
  }
}
