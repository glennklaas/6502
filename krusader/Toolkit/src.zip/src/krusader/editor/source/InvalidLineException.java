package krusader.editor.source;

public class InvalidLineException extends Exception
{

  public InvalidLineException()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  public InvalidLineException(String arg0)
  {
    super(arg0);
    // TODO Auto-generated constructor stub
  }

  public InvalidLineException(String arg0, Throwable arg1)
  {
    super(arg0, arg1);
    // TODO Auto-generated constructor stub
  }

  public InvalidLineException(Throwable arg0)
  {
    super(arg0);
    // TODO Auto-generated constructor stub
  }

}
