package krusader.editor.source;

import java.util.ArrayList;
import java.util.Iterator;

import krusader.common.KEUtils;

public class SourceLine
{
  public static final Byte EOL = 0;
  private static final Byte EOFLD = 1;
  private static final Byte BLANK = 2;

  private static final Byte COMMENT = ';';
  private static final Byte DOT = '.';

  public static final int LABEL_END = 6;
  public static final int MNE_END = 10;
  public static final int ARGS_END = 25;
  public static final int COMMENT_END = 37;

  public static final int LABEL_START = 1;
  public static final int MNE_START = LABEL_END + 2;
  public static final int ARGS_START = MNE_END + 2;
  public static final int COMMENT_START = ARGS_END + 2;
  
  public static final int LABEL_SIZE = 6;
  public static final int MNE_SIZE = 3;
  public static final int ARGS_SIZE = ARGS_END - ARGS_START + 1;
  public static final int COMMENT_SIZE = COMMENT_END - COMMENT_START + 1;
  
  String label;
  Mnemonic mnemonic;
  Directive directive;
  String args;
  String comment;
  
  boolean blankLine;
  boolean commentOnly;

  public SourceLine(String label, String instruction, String args, String comment)
    throws InvalidLineException
  {
    create(label, instruction, args, comment);
  }
  
  private void create(String label, String instruction, String args, String comment) 
    throws InvalidLineException
  {
    this.label = trimIfPossible(label);
    this.args = trimIfPossible(args);
    this.comment = trimIfPossible(comment);
    
    try
    {
      if (instruction != null)
      {
        if (instruction.charAt(0) == '.')
          this.directive = Directive.fromChar(instruction.charAt(1));
        else
          this.mnemonic = Mnemonic.valueOf(instruction);
      }
    }
    catch (IllegalArgumentException iax)
    {
      throw new InvalidLineException();
    }
    
    validate();
  }
  
  private static String trimIfPossible(String word)
  {
    return word == null ? null : word.replace('\n', ' ').trim(); 
  }
  
  public SourceLine(String rawText) throws InvalidLineException
  {
    try
    {
      // append # so only trim from the end
      // also makes column numbers consistent with the editor
      String text = trimIfPossible("#" + rawText.replace('\t', ' ')).toUpperCase();
      // special handling for comment only lines
       if (rawText != null)
      {
        String simpleTrim = rawText.trim();      
        if (simpleTrim.length() > 0 && simpleTrim.charAt(0) == ';')
          text = "#" + simpleTrim.toUpperCase();
      }
      
      if (text.length() == 1)
      {
        blankLine = true;
      }
      else if (text.charAt(1) == ';')
      {
        commentOnly = true;
        this.comment = text.substring(2).trim();
        if (comment.length() > COMMENT_END - MNE_START)
          comment = comment.substring(0, COMMENT_END - MNE_START - 1);
      }
      else
      {
        /*
        Use the following simple rules to interpret a generic format:
        
        - Semicolon at any position indicates a comment
        - Entry in column 1 is a label - truncate to 6 chars if necessary
        - Interpret a label on its own line as .M
        - First entry after a space is a mnemonic or directive
        - Arguments follow the space after the mnemonic, and end at next space or EOL
        - Any text following arguments is ignored (i.e. comments are not translated in generic mode)
        */
  
        // first deal with any comment
        int semicolonPos = text.indexOf(';');
        if (semicolonPos > 0)
        {
          if (semicolonPos < text.length())
          {
            this.comment = text.substring(semicolonPos + 1).trim();
            if (comment.length() > COMMENT_SIZE)
              comment = comment.substring(0, COMMENT_SIZE - 1);
          }
          text = text.substring(0, semicolonPos - 1);
        }
        
        if (text.length() == 1)
          return;
  
        // handle the label
        if (text.charAt(1) == DOT || Character.isLetterOrDigit(text.charAt(1)))
        {
          int nextSpace = text.indexOf(' ');
          int labelEnd = text.indexOf('.');
          if (nextSpace > 0)
          {
            if (labelEnd > 1)
              labelEnd = Math.min(nextSpace, labelEnd);
            else
              labelEnd = nextSpace;
          }
          if (labelEnd < 0)
          {
              // just a label => new module for Krusader
              this.label = text.substring(1).trim().toUpperCase();
              this.directive = Directive.M;
              return;
            }
            else
            {
              // truncate the label if overlong
              this.label = text.substring(1, Math.min(LABEL_SIZE + 1, labelEnd));
              text = text.substring(labelEnd).trim();
            }
          }
          else
          {
            text = text.substring(1).trim();
          }
        
          if (text.length() == 0)
            return;
         
          // if we get this far, we must have a mnemonic or directive
          int instEnd = text.indexOf(' ');
          if (instEnd == -1)
            instEnd = text.length();
          String inst = text.substring(0, instEnd);
          if (text.charAt(0) == DOT)
          {
            directive = Directive.guess(inst);
            if (directive == null && text.length() > 2)
            {
              inst = text.substring(0, 2);
              instEnd = 2;
              directive = Directive.guess(inst);
            }
          }
          else
          {
            mnemonic = Mnemonic.valueOf(inst);
          }
          
          String remains = text.substring(instEnd);
          int l1 = remains.length();
          remains = remains.trim();
          int l2 = remains.length();
          if (l2 == 0)
            return;
          else if (l1 - l2 > 8)
            this.comment = remains;
          else
          {
            // is there any comment left?
            int splitAt = remains.indexOf(' ');
            if (splitAt < 0)
            {
              this.args = remains;
            }
            else
            {
              this.args = remains.substring(0, splitAt);
              this.comment = remains.substring(splitAt + 1).trim();
            }
          }
    
          if (args != null && args.length() > ARGS_SIZE)
            args = args.substring(0, ARGS_SIZE);
          if (comment != null && comment.length() > COMMENT_SIZE)
            comment = comment.substring(0, COMMENT_SIZE);
        }
    }
    catch (Exception x)
    {
      throw new InvalidLineException(x + "\t" + this.toString());
    }
  }
  
  public SourceLine(ArrayList<Byte> tokenisedLine) throws InvalidLineException
  {
    // is it a blank?
    if (tokenisedLine.size() == 2)
    {
      if (tokenisedLine.get(0).equals(BLANK) && tokenisedLine.get(1).equals(EOL))
      {
        blankLine = true;
      }
      else
      {
        throw new InvalidLineException();
      }
    }
    else if (tokenisedLine.get(0).equals(COMMENT) && tokenisedLine.get(1).equals(EOFLD))
    {
      StringBuffer commentBuffer = new StringBuffer();
      commentOnly = true;
      for (byte b : tokenisedLine)
        commentBuffer.append((char)b);
      comment = commentBuffer.substring(2);
    }
    else
    {
      label = detokeniseOneField(tokenisedLine, EOFLD);
      if (tokenisedLine.get(0) <= Mnemonic.numMnemonics)
      {
        mnemonic = Mnemonic.fromToken(tokenisedLine.get(0));
        tokenisedLine.remove(0);
      }
      else
      {
        directive = Directive.fromToken(tokenisedLine.get(0));
        tokenisedLine.remove(0);
      }
      args = detokeniseOneField(tokenisedLine, EOFLD);
      comment = detokeniseOneField(tokenisedLine, EOL);
    }
  }
  
  private String detokeniseOneField(ArrayList<Byte> data, Byte endByte)
  {
    StringBuffer result = new StringBuffer();
    Iterator<Byte> it = data.iterator();
    while (it.hasNext())
    {
      Byte b = it.next();
      it.remove();
      if (endByte.equals(b))
        break;
      result.append((char)b.byteValue());
    }
    
    return result.toString();
  }

  public ArrayList<Byte> tokenise() throws InvalidLineException
  {
    ArrayList<Byte> tokenised = new ArrayList<Byte>();
    
    validate();
    
    if (blankLine)
    {
      tokenised.add(BLANK);
    }
    else if (commentOnly)
    {
      tokenised.add(COMMENT);
      tokenised.add(EOFLD);
      if (comment != null)
      {
        for (byte b : comment.getBytes())
          tokenised.add(b);
      }
    }
    else
    {
      if (label != null)
      {
        for (byte b : label.getBytes())
          tokenised.add(b);
      }
      tokenised.add(EOFLD);
      if (mnemonic != null)
      {
        tokenised.add(mnemonic.tokenValue());
      }
      else if (directive != null)
      {
        tokenised.add(directive.tokenValue());
      }
      else
      {
        throw new InvalidLineException();
      }
      if (args != null)
      {
        for (byte b : args.getBytes())
          tokenised.add(b);
      }
      if (comment != null)
      {
        tokenised.add(EOFLD); // only need to terminate args field if a comment follows
        for (byte b : comment.getBytes())
          tokenised.add(b);
      }
    }
    tokenised.add(EOL);
    
    return tokenised;    
  }

  public boolean isCommentOnly() { return commentOnly; }
  public boolean isBlank() { return blankLine; }

  public String getLabel() { return label; }
  public Mnemonic getMnemonic() { return mnemonic; }
  public Directive getDirective() { return directive; }
  public String getArgs() { return args; }
  public String getComment() { return comment; }
  
  public String getLineText()
  {    
    // is it a blank?
    if (blankLine)
    {
      return "";
    }
    else if (commentOnly)
    {
      return "; " + comment;
    }
    else
    {
      return makeString(label, LABEL_SIZE) + " " + (getInstruction() + " " + 
          makeString(args, ARGS_SIZE) + " " + makeString(comment, COMMENT_SIZE)).trim();
    }
  }
  
  private String getInstruction()
  {
    if (mnemonic != null)
      return mnemonic.toString();
    else if (directive != null)
      return "." + directive.stringValue() + " ";
    else
      return "";  // invalid line
  }

  private String makeString(String string, int length)
  {
    if (string == null)
      return KEUtils.repeat(' ', length);
    else
    {
      int strlen = string.length();
      if (strlen > length)
        return string.substring(0, length - 1);
      else
        return string + KEUtils.repeat(' ', length - strlen);
    }
  }

  public String toString() { return getLineText(); }
  
  public void validate() throws InvalidLineException
  {
    if (commentOnly || blankLine)
      return;
    else if (mnemonic == null && directive == null)
      throw new InvalidLineException();
  }
}
