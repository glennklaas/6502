package krusader.editor;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class SourceDocumentListener implements DocumentListener
{

  public SourceDocumentListener()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  public void insertUpdate(DocumentEvent e)
  {
    // TODO Auto-generated method stub

  }

  public void removeUpdate(DocumentEvent e)
  {
    // TODO Auto-generated method stub

  }

  public void changedUpdate(DocumentEvent e)
  {
    // TODO Auto-generated method stub

  }

}
