package krusader.editor;

import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.plaf.TextUI;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultCaret;
import javax.swing.text.JTextComponent;

public class OvertypeCaret extends DefaultCaret
{
  Character prompt;

  public OvertypeCaret() {}
  
  public OvertypeCaret(Character prompt)
  {
    this.prompt = prompt;
  }
  
  public void paint(Graphics g)
  {
    if (isVisible())
    {
      try
      {
        JTextComponent component = getComponent();
        TextUI mapper = component.getUI();
        Rectangle r = mapper.modelToView(component, getDot());
        g.setColor(component.getCaretColor());
        int width = g.getFontMetrics().charWidth('w');
        int height = g.getFontMetrics().getHeight() - 1;
        if (r.x > 39 * width)	// wrap the cursor
        {
        	r.x = 0;
        	r.y += r.height;
        }
        int y = r.y + r.height - 2;
        if (prompt == null)
          g.fillRect(r.x, y - height + 4, width - 3, height - 3);
        else
          g.drawString(prompt.toString(), r.x, y + 1);
      }
      catch (BadLocationException e)
      {
      }
    }
  }

  /*
   * Damage must be overridden whenever the paint method is overridden (The
   * damaged area is the area the caret is painted in. We must consider the
   * area for the default caret and this caret)
   */
  protected synchronized void damage(Rectangle r)
  {
    if (r != null)
    {
      JTextComponent component = getComponent();
      x = r.x;
      y = r.y;
      width = component.getFontMetrics(component.getFont()).charWidth('w');
      height = component.getFontMetrics(component.getFont()).getHeight();
      x = x - width;
      if (x > 39 * width)
      {
        x = 0;
        y += r.height;
      }
      width *= 2;
      repaint();
    }
  }
}
