package krusader.editor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Set;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

import krusader.common.KEGUIUtils;
import krusader.editor.formats.BinaryData;
import krusader.editor.formats.IntelHexHandler;
import krusader.editor.formats.WozMonitorHexHandler;
import krusader.editor.source.SourceDocument;
import krusader.editor.source.SourceLine;

public class SourceFileHandler
{    
  JFrame parent = null;
  SourceFileChooser fileChooser = null;
  
  public SourceFileHandler(JFrame parent, SourceFileChooser sfc)
  {
    this.parent = parent;
    this.fileChooser = sfc;
    sfc.setFileFilter(new KrusaderSourceFileFilter());
  }
  
  public boolean saveSource(SourceDocument doc) throws IOException
  {
    if (doc == null)
      return false;
    
    if (fileChooser.showSaveDialog(parent) == JFileChooser.CANCEL_OPTION)
      return false;
    
    boolean saved = false;

    KEGUIUtils.setWaitCursor(parent);
    File dataFile = fileChooser.getSelectedFile();
    KrusaderSourceDataType format = fileChooser.getFileType();
    
    FileOutputStream fos = null;
    BufferedWriter bw = null;
    BinaryData sourceData;

    try
    {
      switch (format)
      {
        case TEXT:
          fos = new FileOutputStream(dataFile);
          bw = new BufferedWriter(new OutputStreamWriter(fos));
          for (SourceLine line : doc.getLines())
          {
            bw.write(line.getLineText());
            bw.newLine();
          }
          break;
        case BINARY:
          fos = new FileOutputStream(dataFile);
          ArrayList<Byte> tokDoc = doc.getTokenized();
          byte [] primitiveByteArray = new byte[tokDoc.size()];
          int i = 0;
          for (Byte b : doc.getTokenized())
            primitiveByteArray[i++] = b;
          fos.write(primitiveByteArray);
          break;
        case HEX:
          sourceData = new BinaryData(fileChooser.getAddress(), doc.getTokenized());
          new WozMonitorHexHandler().encode(new OutputStreamWriter(new FileOutputStream(dataFile)), sourceData, 0x10);
          break;
        case INTEL_HEX:
          sourceData = new BinaryData(fileChooser.getAddress(), doc.getTokenized());
          new IntelHexHandler().encode(new OutputStreamWriter(new FileOutputStream(dataFile)), sourceData, 0x10);
          break;
      }
      saved = true;
    }
    catch (Exception x)
    {
      x.printStackTrace();
      JOptionPane.showMessageDialog(parent, x.getMessage(),
          "Source Format Error", JOptionPane.ERROR_MESSAGE);
    }
    if (bw != null) bw.close();
    if (fos != null) fos.close();
    
    return saved;
  }
  
  public SourceDocument loadSource() throws IOException
  {
    if (fileChooser.showOpenDialog(parent) == JFileChooser.CANCEL_OPTION)
      return null;

    KEGUIUtils.setWaitCursor(parent);
    File dataFile = fileChooser.getSelectedFile();
    KrusaderSourceDataType format = 
      KrusaderSourceDataType.fromExtension(fileChooser.getSelectedFileExtension());
    
    SourceDocument source = null;
    
    FileInputStream fis = null;
    BufferedReader br = null;
    BinaryData sourceData;
    
    try
    {
      Set<Integer> addresses;
      switch (format)
      {
        case TEXT:
          String line;
          fis = new FileInputStream(dataFile);
          br = new BufferedReader(new InputStreamReader(fis));
          source = new SourceDocument();
          while ((line = br.readLine()) != null)
          {
            source.addLine(new SourceLine(line));
          }
          break;
        case BINARY:
          fis = new FileInputStream(dataFile);
          int dataSize = (int)dataFile.length();  // conversion is ok here - files never that big
          ArrayList<Byte> data = new ArrayList<Byte>(dataSize);
          byte [] buffer = new byte[dataSize];
          fis.read(buffer, 0, dataSize);
          for (byte b : buffer)
          {
            data.add(b);
          }
          source = new SourceDocument(data);
          break;
        case HEX:
          sourceData = new WozMonitorHexHandler().decode(new InputStreamReader(new FileInputStream(dataFile)));
          addresses = sourceData.getAddresses();
          if (addresses.size() > 1)
            throw new Exception("Hex data is not contiguous");
          source = new SourceDocument(sourceData.getData(addresses.iterator().next()));
          break;
        case INTEL_HEX:
          sourceData = new IntelHexHandler().decode(new InputStreamReader(new FileInputStream(dataFile)));
          addresses = sourceData.getAddresses();
          if (addresses.size() > 1)
            throw new Exception("Hex data is not contiguous");
          source = new SourceDocument(sourceData.getData(addresses.iterator().next()));
          break;
      }
    }
    catch (Exception x)
    {
      JOptionPane.showMessageDialog(parent, x.getMessage(),
          "Source Format Error", JOptionPane.ERROR_MESSAGE);
    }
    if (br != null) br.close();
    if (fis != null) fis.close();
    
    return source;
  }
  
  public class KrusaderSourceFileFilter extends FileFilter
  {
    public boolean accept (File f)
    {
      String extension = f.getName().substring(f.getName().lastIndexOf('.') + 1);
      return f.isDirectory() || KrusaderSourceDataType.isAllowedExtension(extension);
    }
  
    public String getDescription()
    {
      StringBuffer desc = new StringBuffer();
      for (String ext : KrusaderSourceDataType.getAllowedExtensions())
        desc.append("; *." + ext);
      return "Krusader Source (" + desc.substring(2) + ")";
    }
  }
}
