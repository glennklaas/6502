package krusader.editor.formats;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;

import krusader.common.KEUtils;

public class IntelHexHandler implements IFormatHandler
{  
  private static final Byte DATA_RECORD = 0;
  private static final Byte EOF_RECORD = 1;
  private static final int RADIX = 16;

  public BinaryData decode(Reader stream) throws Exception
  {   
    BufferedReader br = new BufferedReader(stream);

    BinaryData data = new BinaryData();
    ArrayList<Byte> bytes = new ArrayList<Byte>();
    
    String line;
    int currentStartAddress = 0;
    int lastAddress = -1;
    while ((line = br.readLine()) != null)
    {      
      // decode line to tokenised bytes
      if (line.charAt(0) != ':')
        throw new Exception("Invalid Intel Hex Format: " + line);            
        
      Byte byteCountByte = Byte.parseByte(line.substring(1, 3), RADIX);
      int byteCount = byteCountByte.intValue();
      int dataAddress = Integer.parseInt(line.substring(3, 7), RADIX);
      Byte type = (byte)Integer.parseInt(line.substring(7, 9), RADIX);
      
      if (type.equals(DATA_RECORD))
      {
        for (int i = 0; i < byteCount; ++i)
        {
          bytes.add((byte)Integer.parseInt(line.substring(9 + 2 * i, 11 + 2 * i), RADIX));
        }
        int checksum = Integer.parseInt(line.substring(9 + 2 * byteCount, 11 + 2 * byteCount), RADIX);
        if (checksum != calcRecordChecksum(line))
        {
          System.err.println("Warning!  Checksum error on line: " + line);
          //throw new Exception("Checksum error on line: " + line);
        }
                
        if (lastAddress < 0)
        {
          currentStartAddress = dataAddress;
          lastAddress = dataAddress;
        }
        else if (lastAddress != dataAddress)
        {
          data.setData(currentStartAddress, bytes);
          currentStartAddress = dataAddress;
          lastAddress = dataAddress;
          bytes = new ArrayList<Byte>();
        }
        
        // exclude the record length, address (2) and type bytes from the returned data 
        lastAddress += byteCount;
      }
      else if (!type.equals(EOF_RECORD))
      {
        throw new Exception("Invalid Intel Hex Format: " + line);
      }
    }
    data.setData(currentStartAddress, bytes);
    
    return data;
  }
  
  public void encode(Writer stream, BinaryData data, int bytesPerLine) throws Exception
  {   
    BufferedWriter bw = new BufferedWriter(stream);

    for (int address : data.getAddresses())
    {
      int byteCount = 0;
      
      StringBuilder record = new StringBuilder(bytesPerLine + 11);
      record.append(":" + Integer.toHexString(bytesPerLine) + 
          KEUtils.toHex(address, 4) + "00");
      
      for (Byte oneByte : data.getData(address))
      {
        record.append(KEUtils.toHex(oneByte, 2));
        if (++byteCount >= bytesPerLine)
        {
          record.append(KEUtils.toHex(calcRecordChecksum(record.toString()), 2));
          bw.write(record.toString());
          bw.newLine();
          record = new StringBuilder(bytesPerLine + 11);
          byteCount = 0;
          address += bytesPerLine;
          record.append(":10" + KEUtils.toHex(address, 4) + "00");
        }
      }

      String size = KEUtils.toHex(byteCount, 2);
      // correct the size for a short line
      record.setCharAt(1, size.charAt(0));
      record.setCharAt(2, size.charAt(1));
      record.append(KEUtils.toHex(calcRecordChecksum(record.toString()), 2));
      bw.write(record.toString());
      bw.newLine();
    }
    bw.write(":00000001FF");
    bw.newLine();
    
    bw.close();
  }
  
  // calculate the checksum of this record - uses all values except the initial ':'
  public static int calcRecordChecksum(String record)
  {
    int sum = 0;

    int byteCount = Integer.parseInt(record.substring(1, 3), RADIX);
    for (int i = 1; i <= 2 * (byteCount + 4); i += 2)
    {
      int oneByte = Integer.parseInt(record.substring(i, i + 2), RADIX);
      sum += oneByte;
    }

    return (0x100 - sum % 256) & 0xFF;
  }
}
