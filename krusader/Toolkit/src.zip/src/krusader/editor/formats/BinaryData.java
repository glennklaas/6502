package krusader.editor.formats;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class BinaryData
{
  HashMap<Integer, DataChunk> data = new HashMap<Integer, DataChunk>();
  
  public BinaryData()
  {
  }
  
  public BinaryData(int address, ArrayList<Byte> data)
  {
    setData(address, data);
  }

  public Set<Integer> getAddresses() 
  { 
    return data.keySet();
  }
  
  public HashMap<Integer, DataChunk> getData() 
  { 
    return data;
  }
  
  public void trimData(int address, int length)
  {
    ArrayList<Byte> dataToTrim = getData(address);
    if (dataToTrim.size() > length)
    {
      dataToTrim = new ArrayList<Byte>(dataToTrim.subList(0, length - 1));
      setData(address, dataToTrim);
    }
  }
  
  public ArrayList<Byte> getData(int address) 
  { 
    return data.get(address).getData();
  }
  
  private DataChunk getChunk(int address) 
  { 
    if (data.containsKey(address))
      return data.get(address);
    else
    {
      data.put(address, new DataChunk(address));
      return getChunk(address);
    }
  }

  public void setData(int address, ArrayList<Byte> data)
  {
    getChunk(address).setData(data);
  }

  public void clearData(int address)
  {
    getChunk(address).clearData();
  }

  public void clearData()
  {
    data.clear();
  }

  class DataChunk
  {
    int address;
    ArrayList<Byte> data;
    
    public DataChunk(int add)
    {
      this(add, new ArrayList<Byte>());
    }
    
    public DataChunk(int add, ArrayList<Byte> data)
    {
      this.address = add;
      this.data = data;
    }
    
    public int getAddress() 
    { 
      return address;
    }

    public void addData(ArrayList<Byte> data)
    {
      if (this.data == null)
        setData(data);
      else
        this.data.addAll(data);
    }

    public void setData(ArrayList<Byte> data)
    {
      this.data = data;
    }

    public void clearData()
    {
      if (this.data != null)
        this.data.clear();
    }
    
    public ArrayList<Byte> getData() 
    { 
      return data;
    }
  }
}
