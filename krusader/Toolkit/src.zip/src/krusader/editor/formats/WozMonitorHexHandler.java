package krusader.editor.formats;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;

import krusader.common.KEUtils;

public class WozMonitorHexHandler implements IFormatHandler
{
  private static final int RADIX = 16;
 
  public BinaryData decode(Reader stream) throws Exception
  {   
    BufferedReader br = new BufferedReader(stream);

    BinaryData data = new BinaryData();
    ArrayList<Byte> bytes = new ArrayList<Byte>();
    
    String line;
    int currentStartAddress = 0;
    int lastAddress = -1;
    while ((line = KEUtils.getNextNonemptyLine(br)) != null)
    {
      // decode line to tokenised bytes
      
      // must start with either an address or a colon - a we ignore the address for the moment
      int dataAddress = 0;
      int dataStart = line.indexOf(':');
      if (dataStart < 0)
        throw new Exception("Invalid Woz Monitor Format: " + line);
      else if (dataStart > 0) // i.e. not simply continuing
      {
        dataAddress = Integer.parseInt(line.substring(0, dataStart), RADIX);
        if (lastAddress < 0)
        {
          currentStartAddress = dataAddress;
          lastAddress = dataAddress;
        }
        else if (lastAddress != dataAddress)
        {
          data.setData(currentStartAddress, bytes);
          currentStartAddress = dataAddress;
          lastAddress = dataAddress;
          bytes = new ArrayList<Byte>();
        }
      }
      else if (lastAddress < 0)
        throw new Exception("No address specified in monitor data");
      
      String dataStr = line.substring(dataStart + 1).trim();
      if (dataStr.length() > 0)
      {
        String [] dataBytes = dataStr.split("[ ]+");
        
        for (String byteString : dataBytes)
        {
          lastAddress++;
          //bytes.add(Byte.parseByte(byteString, RADIX));
          bytes.add((byte)Integer.parseInt(byteString, RADIX));
        }
      }
    }
    data.setData(currentStartAddress, bytes);
    
    return data;
  }
  
  public void encode(Writer stream, BinaryData data, int bytesPerLine) throws IOException
  {   
    BufferedWriter bw = new BufferedWriter(stream);

    for (int address : data.getAddresses())
    {
      int byteCount = 0;
      bw.write(KEUtils.toHex(address, 4) + ": ");
      for (Byte oneByte : data.getData(address))
      {
        bw.write(KEUtils.toHex(oneByte, 2));
        if (++byteCount == bytesPerLine)
        {
          byteCount = 0;
          bw.newLine();
          address += bytesPerLine;
          bw.write(KEUtils.toHex(address, 4) + ": ");
        }
        else
        {
          bw.write(" ");
        }
      }
      bw.newLine();
    }
    bw.close();
  }
}
