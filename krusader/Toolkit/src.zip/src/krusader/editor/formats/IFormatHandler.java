package krusader.editor.formats;

import java.io.Reader;
import java.io.Writer;

public interface IFormatHandler
{
  public BinaryData decode(Reader stream) throws Exception;

  public void encode(Writer stream, BinaryData rawData, int bytesPerLine)
      throws Exception;
}