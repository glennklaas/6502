package krusader.editor;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.filechooser.FileSystemView;

public class SourceFileChooser extends JFileChooser
{ 
  JPanel formatPanel;
  ButtonGroup formatGroup = new ButtonGroup();
  JTextField addressField = new JTextField("$nnnn");
  
  KrusaderSourceDataType selectedType = KrusaderSourceDataType.TEXT;
  
  public SourceFileChooser()
  {
    this((File)null, (FileSystemView)null);
  }

  public SourceFileChooser(File currentDirectory, FileSystemView fsv)
  {
    super(currentDirectory, fsv);
    createFormatPanel();
  }

  public SourceFileChooser(String currentDirectoryPath, FileSystemView fsv)
  {
    super(currentDirectoryPath, fsv);
    createFormatPanel();
  }
  
  private void createFormatPanel()
  {
    formatPanel = new JPanel(new GridLayout(7 + KrusaderSourceDataType.values().length, 1));
    
    formatPanel.add(new JLabel(""));
    formatPanel.add(new JLabel(""));
    formatPanel.add(new JLabel(""));
    formatPanel.add(new JLabel("Choose format: "));
    
    for (KrusaderSourceDataType format : KrusaderSourceDataType.values())
    {
      JRadioButton button = new JRadioButton(format.toString());
      button.setActionCommand(format.toString());
      button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          selectedType = KrusaderSourceDataType.valueOf(e.getActionCommand());
          addressField.setEnabled(selectedType.equals(KrusaderSourceDataType.INTEL_HEX) ||
              selectedType.equals(KrusaderSourceDataType.HEX));
          fixExtension();
        }
      });
      formatPanel.add(button);
      formatGroup.add(button);
    }
    formatPanel.add(new JLabel("Address:"));
    formatPanel.add(addressField);
    formatPanel.add(new JLabel(""));
    
    formatPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
    setFileType(selectedType);
  }
  
  public String getSelectedFileExtension()
  {
    File f = getSelectedFile();
    if (f == null)
      return null;
    String fileName = f.getName();
    int extensionStart = fileName.lastIndexOf('.') + 1;
    if (extensionStart < 0)
      return "";
    else
      return fileName.substring(extensionStart);   
  }

  private void fixExtension()
  {
    File f = getSelectedFile();
    if (f == null)
      return;
    String fileName = f.getName();
    int extensionStart = fileName.lastIndexOf('.') + 1;
    if (extensionStart < 0)
      extensionStart = fileName.length() - 1;
    String extension = fileName.substring(extensionStart);
    String requiredExtension = selectedType.toExtension(); 
    if (!requiredExtension.equals(extension))
    {
      String fixedName = fileName.substring(0, extensionStart) + requiredExtension;
      setSelectedFile(new File(fixedName));
    }
  }
  
  public KrusaderSourceDataType getFileType()
  {
    return KrusaderSourceDataType.valueOf(formatGroup.getSelection().getActionCommand());
  }
  
  public void setFileType(KrusaderSourceDataType type)
  {
    Enumeration<AbstractButton> buttonIt = formatGroup.getElements();
    while (buttonIt.hasMoreElements())
    {
      AbstractButton button = buttonIt.nextElement();
      if (button.getActionCommand().equals(type.toString()))
      {
        button.setSelected(true);
      }
    }
  }
  
  public int getAddress()
  {
    if (getDialogType() == OPEN_DIALOG)
      throw new IllegalStateException("No address specification for open dialogs");
    else if (selectedType.equals(KrusaderSourceDataType.TEXT) ||
        selectedType.equals(KrusaderSourceDataType.BINARY))
      throw new IllegalStateException("No address specification for binary or text formats");
    else
    {
      String text = addressField.getText().trim();
      if (text.length() < 0)
        return 0;
      if (text.charAt(0) == '$')
        return Integer.parseInt(text.substring(1), 16);
      else
        return Integer.parseInt(text, 10);
    }
  }

  public int showOpenDialog(Component parent) throws HeadlessException
  {
    this.setAccessory(null);
    return super.showOpenDialog(parent);
  }

  public int showSaveDialog(Component parent) throws HeadlessException
  {
    this.setAccessory(formatPanel);
    return super.showSaveDialog(parent);
  }
}
