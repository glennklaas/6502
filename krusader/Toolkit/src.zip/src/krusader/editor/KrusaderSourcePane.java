package krusader.editor;

import java.awt.Graphics;

import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Caret;
import javax.swing.text.Document;

public class KrusaderSourcePane extends JTextPane
{
  private EditorPane parent;
  Caret defaultCaret = null;
  OvertypeCaret overtypeCaret = new OvertypeCaret();

  public KrusaderSourcePane(EditorPane pane)
  {
    parent = pane;
    defaultCaret = getCaret();
    overtypeCaret.setBlinkRate(defaultCaret.getBlinkRate());

    setCaret(overtypeCaret);
    
//    KeyboardFocusManager manager = KeyboardFocusManager
//        .getCurrentKeyboardFocusManager();
//    manager.addKeyEventDispatcher(new KeyEventDispatcher()
//    {
//      public boolean dispatchKeyEvent(KeyEvent k)
//      {
//        System.out.println("KrusaderSourcePane");
//        if (k.getID() == KeyEvent.KEY_TYPED
//            && KrusaderSourcePane.this.hasFocus())
//        {
//          KrusaderSourcePane.this.parent.dispatchEvent(k);
//          EmulatorPane.this.requestFocus();
//          return true;
//        }
//        else
//        {
//          return false;
//        }
//      }
//    });
  }

  // OvertypeCaret overtypeCaret = new OvertypeCaret();
  // overtypeCaret.setBlinkRate( defaultCaret.getBlinkRate() );

  public void paint(Graphics g)
  {
    super.paint(g);
    parent.repaint();
  }

  public void appendText(String text)
  {
    Document doc = getDocument();
    try
    {
      doc.insertString(doc.getLength(), text, null);
    }
    catch (BadLocationException e)
    {
      e.printStackTrace();
    } 
  }
};