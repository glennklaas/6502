package krusader.editor;

import javax.swing.event.UndoableEditEvent;

public class UndoableEditListener implements
    javax.swing.event.UndoableEditListener
{

  public UndoableEditListener()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  public void undoableEditHappened(UndoableEditEvent e)
  {
    // Remember the edit and update the menus.
//    undo.addEdit(e.getEdit());
//    undoAction.updateUndoState();
//    redoAction.updateRedoState();
  }

}
